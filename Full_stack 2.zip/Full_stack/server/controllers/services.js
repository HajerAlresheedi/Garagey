// routes/services.js
const express = require("express");
const router = express.Router();
const Garage = require("../models/garage");

// POST endpoint for creating a service for a specific garage
router.post("/garages/:garageId/services", async (req, res) => {
  try {
    const garageId = req.params.garageId;
    const {
      serviceName,
      price,
      description,
      duration,
      customerNumber,
      availability,
    } = req.body;

    // Create a new service
    const newService = {
      serviceName,
      price,
      description,
      duration,
      customerNumber,
      availability,
    };

    // Find the garage by ID and update the services array
    const updatedGarage = await Garage.findByIdAndUpdate(
      garageId,
      { $push: { services: newService } },
      { new: true }
    );

    if (!updatedGarage) {
      return res.status(404).json({
        success: false,
        errors: {
          field: "Garage",
          error: "Garage not found",
          solution: "Check your garage ID and try again",
        },
      });
    }

    res.status(201).json({
      success: true,
      status_code: 201,
      data: updatedGarage,
      errors: null,
    });
  } catch (error) {
    console.error("Error creating service:", error);
    res.status(500).json({
      success: false,
      status_code: 500,
      errors: {
        field: "Server",
        error: "Internal Server Error",
        solution: "Please try again later",
      },
    });
  }
});

module.exports = router;
