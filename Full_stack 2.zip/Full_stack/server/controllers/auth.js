const { validateLogin } = require("../middlewares/validate");
const Garage = require("../models/garage");
const User = require("../models/user");
const { CreateUser, CreateGarage } = require("../utils/creator");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const sign_up = async (req, res) => {
  try {
    const body = req.body;
    if (body.type === "user") {
      CreateUser(req, res);
    } else if (body.type === "garage") {
      CreateGarage(req, res);
    } else {
      res.status(400).json({
        success: false,
        errors: [
          {
            field: "Type",
            error: "Bad Request",
            solution:
              "make sure you send it with key 'type', or it's not empty ",
          },
        ],
      });
    }
  } catch (error) {
    res.status(500).json({
      success: false,
      error_message: "internal server error",
      error: error,
    });
    console.error(error);
  }
};
const login = async (req, res) => {
  try {
    const { email, password } = req.body;
    const errors = validateLogin(req.body);
    if (errors.length > 0) {
      return res
        .status(400)
        .json({ success: false, status_code: 400, errors: errors });
    }
    // Check for user in the User collection
    const user = await User.findOne({ email });

    if (user) {
      // User found in User collection
      const passwordMatch = await bcrypt.compare(password, user.password);

      if (!passwordMatch) {
        return res.status(401).json({
          success: false,
          status_code: 401,
          errors: {
            field: "Password",
            error: "Incorrect password",
            solution: "Check your password and try again",
          },
        });
      }

      // Generate a JWT token for authentication for user
      const secretKey = process.env.SECRET_KEY;
      const token = jwt.sign({ user_id: user._id, type: "user" }, secretKey, {
        expiresIn: "1h", // Set the expiration time as needed
      });

      return res.status(200).json({
        success: true,
        status_code: 200,
        token,
        data: "User logged in successfully",
        errors: null,
      });
    }

    // Check for garage in the Garage collection
    const garage = await Garage.findOne({ email });

    if (garage) {
      // Garage found in Garage collection
      const passwordMatch = await bcrypt.compare(password, garage.password);

      if (!passwordMatch) {
        return res.status(401).json({
          success: false,
          status_code: 401,
          errors: {
            field: "Password",
            error: "Incorrect password",
            solution: "Check your password and try again",
          },
        });
      }

      // Generate a JWT token for authentication for garage
      const secretKey = process.env.SECRET_KEY;
      const token = jwt.sign(
        { user_id: garage._id, type: "garage" },
        secretKey,
        {
          expiresIn: "1h", // Set the expiration time as needed
        }
      );

      return res.status(200).json({
        success: true,
        status_code: 200,
        token,
        data: "Garage logged in successfully",
        errors: null,
      });
    }

    // If neither user nor garage found
    return res.status(401).json({
      success: false,
      status_code: 401,
      errors: {
        field: "Email",
        error: "User not found",
        solution: "Check your email and try again",
      },
    });
  } catch (error) {
    console.error("Error during login:", error);
    res.status(500).json({
      success: false,
      status_code: 500,
      errors: {
        field: "Server",
        error: "Internal Server Error",
        solution: "Please try again later",
      },
    });
  }
};

module.exports = {
  sign_up,
  login,
};
