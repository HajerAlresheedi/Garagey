const express = require("express");
const router = express.Router();
const Reservation = require("../models/reservation");

// POST endpoint for creating a reservation
router.post("/reservation", async (req, res) => {
  try {
    // Extract data from the request body
    const {
      user_id,
      serviceName,
      price,
      availability,
      car,
      description,
      duration,
      storeName,
    } = req.body;

    // Create a new Reservation document
    const newReservation = new Reservation({
      user_id,
      serviceName,
      price,
      availability,
      car,
      description,
      duration,
      storeName,
    });

    // Save the reservation to the database
    const createdReservation = await newReservation.save();

    res.status(201).json({
      success: true,
      status_code: 201,
      data: createdReservation,
      errors: null,
    });
  } catch (error) {
    console.error("Error creating reservation:", error);
    res.status(500).json({
      success: false,
      status_code: 500,
      errors: {
        field: "Server",
        error: "Internal Server Error",
        solution: "Please try again later",
      },
    });
  }
});

// GET endpoint to retrieve all reservations for a user_id
router.get("/reservations/:user_id", async (req, res) => {
  try {
    const { user_id } = req.params;

    // Retrieve all reservations for the specified user_id
    const userReservations = await Reservation.find({ user_id });

    res.status(200).json({
      success: true,
      status_code: 200,
      data: userReservations,
      errors: null,
    });
  } catch (error) {
    console.error("Error retrieving reservations:", error);
    res.status(500).json({
      success: false,
      status_code: 500,
      errors: {
        field: "Server",
        error: "Internal Server Error",
        solution: "Please try again later",
      },
    });
  }
});

module.exports = router;
