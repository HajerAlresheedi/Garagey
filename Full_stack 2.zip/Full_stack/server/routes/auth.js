const express = require("express");
const { sign_up, login } = require("../controllers/auth");
const router = express.Router();

router.post("/sign-up", sign_up);
router.post("/login", login);

module.exports = router;
