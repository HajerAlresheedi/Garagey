const bcrypt = require("bcrypt");
const { validateUser, validateGarage } = require("../middlewares/validate");
const User = require("../models/user");
const Garage = require("../models/garage");

// Middleware to handle user creation
const CreateUser = async (req, res) => {
  const body = req.body;
  const errors = validateUser(body);

  if (errors.length > 0) {
    return res
      .status(400)
      .json({ success: false, status_code: 400, errors: errors });
  }

  try {
    // Check if the user already exists
    const existingUser = await User.findOne({ email: body.email });

    if (existingUser) {
      return res.status(409).json({
        success: false,
        status_code: 409,
        errors: {
          field: "Email",
          error: "User already exists with this email",
          solution: "Use a different email address",
        },
      });
    }

    // Hash the password
    const saltRounds = 10;
    const hashedPassword = await bcrypt.hash(body.password, saltRounds);

    // Create a new user object
    const newUser = new User({
      first_name: body.first_name,
      last_name: body.last_name,
      email: body.email,
      password: hashedPassword,
      location: body.location,
      phone_number: body.phone_number,
    });

    // Save the user to the database
    const createdUser = await newUser.save();

    return res.status(201).json({
      success: true,
      status_code: 201,
      data: { id: createdUser._id },
      errors: null,
    });
  } catch (error) {
    console.error("Error creating user:", error);
    return res.status(500).json({
      success: false,
      status_code: 500,
      errors: {
        field: "Server",
        error: "Internal Server Error",
        solution: "Please try again later",
      },
    });
  }
};

// Middleware to handle garage creation
const CreateGarage = async (req, res) => {
  const body = req.body;
  const errors = validateGarage(body);

  if (errors.length > 0) {
    return res
      .status(400)
      .json({ success: false, status_code: 400, errors: errors });
  }

  try {
    // Check if the garage already exists
    const existingGarage = await Garage.findOne({ email: body.email });

    if (existingGarage) {
      return res.status(409).json({
        success: false,
        status_code: 409,
        errors: {
          field: "Email",
          error: "Garage already exists with this email",
          solution: "Use a different email address",
        },
      });
    }
    const saltRounds = 10;
    const hashedPassword = await bcrypt.hash(body.password, saltRounds);
    const newGarage = new Garage({
      avatar: req.filename,
      garage_name: body.garage_name,
      password: hashedPassword,
      email: body.email,
      location: body.location,
      phone_number: body.phone_number,
      garage_type: body.garage_type,
      description: body.description,
      services: body.services,
    });

    const createdGarage = await newGarage.save();

    return res.status(201).json({
      success: true,
      status_code: 201,
      data: { id: createdGarage._id },
      errors: null,
    });
  } catch (error) {
    console.error("Error creating garage:", error);
    return res.status(500).json({
      success: false,
      status_code: 500,
      errors: {
        field: "Server",
        error: "Internal Server Error",
        solution: "Please try again later",
      },
    });
  }
};

module.exports = { CreateUser, CreateGarage };
