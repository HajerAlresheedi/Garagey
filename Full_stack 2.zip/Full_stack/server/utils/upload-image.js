const multer = require("multer");
const path = require("path");

// Multer configuration for image upload
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, path.join(__dirname, "../uploads")); // Set the destination folder for uploaded images
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
    const ext = path.extname(file.originalname);
    const filename = "image-" + uniqueSuffix + ext; // Set the filename for the uploaded image
    req.filename = filename; // Store the filename in the request object
    cb(null, filename);
  },
});

const upload = multer({ storage: storage }).single("avatar");
const uploadImage = (req, res, next) => {
  upload(req, res, function (err) {
    if (err instanceof multer.MulterError) {
      console.error("Multer Error:", err);
      return res.status(500).json({
        success: false,
        errors: {
          field: "Avatar",
          error: "Internal Server Error",
          solution: "Please try again later",
        },
      });
    } else if (err) {
      console.error("Error:", err);
      return res.status(500).json({
        success: false,
        errors: {
          field: "Server",
          error: "Internal Server Error",
          solution: "Please try again later",
        },
      });
    }

    next();
  });
};

module.exports = uploadImage;
