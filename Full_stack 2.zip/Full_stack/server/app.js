const express = require("express");
const authRouter = require("./routes/auth");
require("dotenv").config();
const mongoose = require("mongoose");
const uploadImage = require("./utils/upload-image");

const port = process.env.PORT || 3550;

const app = express();

app.use(express.urlencoded({ extended: true }));
app.use(express.json());

mongoose.connect(process.env.MONGO_DB_URI);

const db = mongoose.connection;

db.on("error", console.error.bind(console, "MongoDB connection error:"));
db.once("open", () => {
  console.log("Connected to MongoDB");
});

app.use("/auth", uploadImage, authRouter);

app.listen(port, () => {
  console.log("server is listening on port " + port);
});
