const { Schema, model } = require("mongoose");

const availibatyScheme = Schema({
  day: { type: "string", required: true },
  hour: { type: "string", required: true },
  date: { type: "string", required: true },
});

const serviceSchema = Schema({
  title: { type: "string", required: true },
  price: { type: "string", required: true },
  customers_at_once: { type: "string", required: true },
  customers: { type: "string", required: true },
  duration: { type: "string", required: true },
  description: { type: "string", required: true },
  availibaty: availibatyScheme,
});

const garageSchema = new Schema({
  garage_name: { type: String, required: true },
  avatar: { type: String, required: true },
  password: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  location: { type: String, required: true },
  phone_number: { type: String, required: true },
  garage_type: { type: String, required: true },
  description: { type: String, required: true },
  services: [serviceSchema],
});

const Garage = model("Garage", garageSchema);

module.exports = Garage;
