const { Schema, model } = require("mongoose");
const carScheme = new Schema({
  name: { type: String },
});

const userSchema = new Schema({
  first_name: { type: String, required: true },
  last_name: { type: String, required: true },
  password: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  location: { type: String, required: true },
  phone_number: { type: String, required: true },
  cars: [carScheme],
});

const User = model("User", userSchema);

module.exports = User;
