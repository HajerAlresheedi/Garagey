const { Schema, model } = require("mongoose");

const reservationScheme = new Schema({
  user_id: { type: String, required: true },
  serviceName: String,
  price: String,
  availability: [
    {
      day: String,
      hours: Number,
      time: String,
    },
  ],
  car: String,
  description: String,
  duration: String,
  storeName: String,
});

const Reservation = model("Reservation", reservationScheme);

module.exports = Reservation;
