const emailRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;

const validateEmail = (email) => {
  return emailRegex.test(email);
};

const validateUser = (body) => {
  const errors = [];
  if (!body.first_name) {
    errors.push({
      field: "First Name",
      error: "Bad Request",
      solution:
        "make sure you send it with key 'first_name', or it's not empty ",
    });
  }
  if (!body.last_name) {
    errors.push({
      field: "Last Name",
      error: "Bad Request",
      solution:
        "make sure you send it with key 'last_name', or it's not empty ",
    });
  }
  if (!body.password) {
    errors.push({
      field: "password",
      error: "Bad Request",
      solution: "make sure you send it with key 'password', or it's not empty ",
    });
  }
  if (!body.email) {
    errors.push({
      field: "email",
      error: "Bad Request",
      solution: "make sure you send it with key 'email', or it's not empty ",
    });
  } else if (!validateEmail(body.email)) {
    errors.push({
      field: "email",
      error: "Bad Request",
      solution: "Please enter a valid email",
    });
  }
  if (!body.location) {
    errors.push({
      field: "location",
      error: "Bad Request",
      solution: "make sure you send it with key 'location', or it's not empty ",
    });
  }
  if (!body.phone_number) {
    errors.push({
      field: "Phone Number",
      error: "Bad Request",
      solution:
        "make sure you send it with key 'phone_number', or it's not empty ",
    });
  }
  return errors;
};
const validateServiceAvailability = (availability) => {
  const errors = [];
  if (!availability.day) {
    errors.push({
      field: "Availability Day",
      error: "Bad Request",
      solution: "Make sure you provide the availability day",
    });
  }
  if (!availability.hour) {
    errors.push({
      field: "Availability Hour",
      error: "Bad Request",
      solution: "Make sure you provide the availability hour",
    });
  }
  if (!availability.date) {
    errors.push({
      field: "Availability Date",
      error: "Bad Request",
      solution: "Make sure you provide the availability date",
    });
  }
  return errors;
};

const validateService = (service) => {
  const errors = [];
  if (!service.title) {
    errors.push({
      field: "Service Title",
      error: "Bad Request",
      solution: "Make sure you provide the service title",
    });
  }
  // Add validations for other service properties as needed

  // Validate service availability
  const availabilityErrors = validateServiceAvailability(service.availability);
  errors.push(...availabilityErrors);

  return errors;
};

const validateGarage = (body) => {
  const errors = [];
  if (!body.garage_name) {
    errors.push({
      field: "Garage Name",
      error: "Bad Request",
      solution: "Make sure you provide the garage name",
    });
  }
  if (!body.password) {
    errors.push({
      field: "Password",
      error: "Bad Request",
      solution: "Make sure you provide the password",
    });
  }
  if (!body.email) {
    errors.push({
      field: "Email",
      error: "Bad Request",
      solution: "Make sure you provide the email",
    });
  } else if (!validateEmail(body.email)) {
    errors.push({
      field: "Email",
      error: "Bad Request",
      solution: "Please enter a valid email",
    });
  }
  if (!body.location) {
    errors.push({
      field: "Location",
      error: "Bad Request",
      solution: "Make sure you provide the location",
    });
  }
  if (!body.phone_number) {
    errors.push({
      field: "Phone Number",
      error: "Bad Request",
      solution: "Make sure you provide the phone number",
    });
  }
  if (!body.garage_type) {
    errors.push({
      field: "Garage Type",
      error: "Bad Request",
      solution: "Make sure you provide the garage type",
    });
  }
  if (!body.description) {
    errors.push({
      field: "Description",
      error: "Bad Request",
      solution: "Make sure you provide the description",
    });
  }

  // Validate each service in the services array
  if (body.services && Array.isArray(body.services)) {
    body.services.forEach((service, index) => {
      const serviceErrors = validateService(service);
      if (serviceErrors.length > 0) {
        errors.push({
          field: `Service at index ${index}`,
          error: "Bad Request",
          solution: "Fix service validation errors",
          details: serviceErrors,
        });
      }
    });
  }

  return errors;
};

const validateLogin = (body) => {
  const errors = [];
  const { email, password } = body;
  if (!email) {
    errors.push({
      field: "email",
      error: "Bad Request",
      solution: "Make sure you provide the email",
    });
  } else if (!validateEmail(email)) {
    errors.push({
      field: "email",
      error: "Bad Request",
      solution: "Please enter a valid email",
    });
  }
  if (!password) {
    errors.push({
      field: "password",
      error: "Bad Request",
      solution: "Make sure you provide the password",
    });
  }
  return errors;
};

module.exports = { validateUser, validateGarage, validateLogin };
