import React, { useEffect, useState } from "react";
import { Container, Table } from "react-bootstrap";

const Reservation = () => {
  const [checkoutData, setCheckoutData] = useState([]);

  useEffect(() => {
    const storedCheckoutData = JSON.parse(localStorage.getItem("reservations"));
    if (storedCheckoutData) {
      setCheckoutData(storedCheckoutData);
    }
  }, []);

  return (
    <Container className="py-5 height-fix">
      <h1 className="mb-4">Reservations</h1>
      {checkoutData.length === 0 ? (
        <p>
          No reservations available. Please proceed with the checkout first.
        </p>
      ) : (
        <Table striped bordered hover>
          <thead>
            <tr>
              <th>Service Name</th>
              <th>Car</th>
              <th>Garage Name</th>
              <th>Availability</th>
            </tr>
          </thead>
          <tbody>
            {checkoutData.map((data, index) => (
              <tr key={index}>
                <td>{data.serviceName}</td>
                <td>{data.car}</td>
                <td>{data.storeName}</td>
                <td>
                  {data.availability.map((slot, i) => (
                    <div key={i}>
                      <strong>Day:</strong> {slot.day}, <strong>Hour:</strong>{" "}
                      {slot.hours}
                    </div>
                  ))}
                </td>
              </tr>
            ))}
          </tbody>
        </Table>
      )}
    </Container>
  );
};

export default Reservation;
