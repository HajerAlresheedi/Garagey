import React, { useEffect, useState } from "react";
import {
  FaImage,
  FaStore,
  FaBook,
  FaPhone,
  FaEnvelope,
  FaLock,
  FaLocationArrow,
  FaTimes,
} from "react-icons/fa";
import Select from "react-select";
import { Container, Form, Button, Col, Row, InputGroup } from "react-bootstrap";

function SignupGarageForm({ handleToggleCard }) {
  const [imagePreview, setImagePreview] = useState(null);
  const [signupErrors, setSignupErrors] = useState({
    image: "",
    storeName: "",
    description: "",
    phoneNumber: "",
    email: "",
    garageType: "",
    password: "",
  });
  const [signupData, setSignupData] = useState({
    image: "",
    storeName: "",
    description: "",
    phoneNumber: "",
    email: "",
    garageType: "",
    password: "",
    location: "",
  });
  const garageTypes = ["Repair Shop", "Car Wash", "Parking Garage", "Other"];

  useEffect(() => {
    console.log("Image Preview (after update):", imagePreview);
  }, [imagePreview]);

  const handleInputChange = (e, formType) => {
    const { name, files } = e.target;

    if (formType === "signup") {
      if (name === "image") {
        handleImagePreview(files);
      }

      setSignupData((prevData) => ({
        ...prevData,
        [name]: files ? files[0] : e.target.value,
      }));

      setSignupErrors((prevErrors) => ({ ...prevErrors, [name]: "" }));
    }
  };

  const handleImagePreview = (files) => {
    if (files && files.length > 0) {
      const reader = new FileReader();
      reader.onload = (event) => {
        setImagePreview(event.target.result);
      };
      reader.readAsDataURL(files[0]);
    } else {
      setImagePreview(null);
    }
  };

  const handleRemoveImage = () => {
    setImagePreview(null);
    setSignupData((prevData) => ({ ...prevData, image: "" }));
  };

  const handleGetLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          setSignupData((prevData) => ({
            ...prevData,
            location: `Latitude: ${latitude}, Longitude: ${longitude}`,
          }));
        },
        (error) => {
          console.error("Error getting location:", error.message);
          setSignupData((prevData) => ({
            ...prevData,
            location: "Failed to get location",
          }));
        }
      );
    } else {
      setSignupData((prevData) => ({
        ...prevData,
        location: "Geolocation is not supported by this browser.",
      }));
    }
  };

  const handleGarageTypeSelect = (selectedOption) => {
    setSignupData((prevData) => ({
      ...prevData,
      garageType: selectedOption,
    }));
  };

  const handleSignupSubmit = (e) => {
    e.preventDefault();

    if (validateSignup()) {
      const existingRegisterData =
        JSON.parse(localStorage.getItem("registerData")) || [];

      const reader = new FileReader();
      reader.onload = (event) => {
        const imageData = event.target.result;

        const garageData = {
          ...signupData,
          image: imageData,
          services: [],
          type: "garage",
        };

        const updatedRegisterData = [...existingRegisterData, garageData];

        localStorage.setItem(
          "registerData",
          JSON.stringify(updatedRegisterData)
        );

        handleToggleCard();
      };

      reader.readAsDataURL(signupData.image);
    }
  };

  const validateSignup = () => {
    let isValid = true;
    const errors = {};

    if (
      !signupData.image ||
      (typeof signupData.image === "string" &&
        !signupData.image.startsWith("data:image"))
    ) {
      errors.image = "Image is required";
      isValid = false;
    }

    if (!signupData.storeName) {
      errors.storeName = "Store Name is required";
      isValid = false;
    }

    if (!signupData.description) {
      errors.description = "Description is required";
      isValid = false;
    }

    if (!signupData.phoneNumber) {
      errors.phoneNumber = "Phone Number is required";
      isValid = false;
    }

    if (!signupData.email) {
      errors.email = "Email is required";
      isValid = false;
    } else if (!/^\S+@\S+$/i.test(signupData.email)) {
      errors.email = "Valid email address is required";
      isValid = false;
    }

    if (!signupData.garageType) {
      errors.garageType = "Garage Type is required";
      isValid = false;
    }

    if (!signupData.password) {
      errors.password = "Password is required";
      isValid = false;
    }

    setSignupErrors(errors);
    return isValid;
  };

  return (
    <Container>
      <Form onSubmit={handleSignupSubmit}>
        <h1>Garage Sign Up</h1>
        <Row>
          <Col>
            <Form.Group className="mb-3">
              <InputGroup hasValidation>
                <InputGroup.Text className="input-icon">
                  <FaImage />
                </InputGroup.Text>
                <Form.Control
                  id="image-upload"
                  type="file"
                  accept="image/*"
                  name="image"
                  onChange={(e) => handleInputChange(e, "signup")}
                  isInvalid={!!signupErrors.image}
                />
              </InputGroup>
              {imagePreview && (
                <div className="image-preview">
                  <img src={imagePreview} alt="Preview" />
                  <FaTimes onClick={handleRemoveImage} />
                </div>
              )}
              <Form.Control.Feedback type="invalid">
                {signupErrors.image}
              </Form.Control.Feedback>
            </Form.Group>
          </Col>
          <Col>
            <Form.Group className="mb-3">
              <InputGroup hasValidation>
                <InputGroup.Text className="input-icon">
                  <FaStore />
                </InputGroup.Text>
                <Form.Control
                  type="text"
                  placeholder="Store Name"
                  name="storeName"
                  value={signupData.storeName}
                  onChange={(e) => handleInputChange(e, "signup")}
                  isInvalid={!!signupErrors.storeName}
                />
              </InputGroup>
              <Form.Control.Feedback type="invalid">
                {signupErrors.storeName}
              </Form.Control.Feedback>
            </Form.Group>
          </Col>
        </Row>
        <Row>
          <Col>
            <Form.Group className="mb-3">
              <InputGroup hasValidation>
                <InputGroup.Text className="input-icon">
                  <FaPhone />
                </InputGroup.Text>
                <Form.Control
                  type="text"
                  placeholder="Phone Number"
                  name="phoneNumber"
                  value={signupData.phoneNumber}
                  onChange={(e) => handleInputChange(e, "signup")}
                  isInvalid={!!signupErrors.phoneNumber}
                />
              </InputGroup>
              <Form.Control.Feedback type="invalid">
                {signupErrors.phoneNumber}
              </Form.Control.Feedback>
            </Form.Group>
          </Col>
        </Row>
        <Col>
          <Form.Group className="mb-3">
            <InputGroup hasValidation>
              <InputGroup.Text className="input-icon">
                <FaEnvelope />
              </InputGroup.Text>
              <Form.Control
                type="email"
                placeholder="Email Address"
                name="email"
                value={signupData.email}
                onChange={(e) => handleInputChange(e, "signup")}
                isInvalid={!!signupErrors.email}
              />
            </InputGroup>
            <Form.Control.Feedback type="invalid">
              {signupErrors.email}
            </Form.Control.Feedback>
          </Form.Group>
        </Col>
        <Row>
          <div className="col">
            <div className="input-group">
              <span className="input-icon">
                <FaLocationArrow />
              </span>
              <button
                type="button"
                className="btn btn-secondary btn-sm me-2"
                onClick={handleGetLocation}
              >
                Get Location
              </button>
              {signupData.location && (
                <div className="location-info">{signupData.location}</div>
              )}
            </div>
            {signupErrors.location && (
              <div className="invalid-feedback">{signupErrors.location}</div>
            )}
          </div>
          <Row>
            <Col>
              <Form.Group className="mb-3">
                <Select
                  options={garageTypes.map((type) => ({
                    value: type,
                    label: type,
                  }))}
                  value={signupData.garageType}
                  onChange={handleGarageTypeSelect}
                  placeholder="Select Garage Type"
                  isMulti
                  className={signupErrors.garageType ? "is-invalid" : ""}
                />
              </Form.Group>
            </Col>
          </Row>
        </Row>
        <Form.Group className="mb-3">
          <InputGroup hasValidation>
            <InputGroup.Text className="input-icon">
              <FaLock />
            </InputGroup.Text>
            <Form.Control
              type="password"
              placeholder="Password"
              name="password"
              value={signupData.password}
              onChange={(e) => handleInputChange(e, "signup")}
              isInvalid={!!signupErrors.password}
            />
          </InputGroup>
          <Form.Control.Feedback type="invalid">
            {signupErrors.password}
          </Form.Control.Feedback>
        </Form.Group>
        <Form.Group className="mb-3">
          <InputGroup hasValidation>
            <InputGroup.Text className="input-icon">
              <FaBook />
            </InputGroup.Text>
            <Form.Control
              as="textarea"
              placeholder="Description"
              name="description"
              value={signupData.description}
              onChange={(e) => handleInputChange(e, "signup")}
              isInvalid={!!signupErrors.description}
            />
          </InputGroup>
          <Form.Control.Feedback type="invalid">
            {signupErrors.description}
          </Form.Control.Feedback>
        </Form.Group>
        <Button type="submit" variant="primary" className="done-btn mb-3 mt-3">
          Sign up
        </Button>
        <p className="loginsignup-login" onClick={handleToggleCard}>
          Already have an account? <span>Login here</span>
        </p>
      </Form>
    </Container>
  );
}

export default SignupGarageForm;
