import React, { useState } from "react";
import "./LoginSignup.css";
import LoginForm from "./components/login-form";
import SignupForm from "./components/sign-up-form";
import SignupGarageForm from "./components/sign-up-garage";

function LoginSignup() {
  const handleToggleCard = () => {
    setShowLogin((prev) => !prev);
  };
  const [showLogin, setShowLogin] = useState(true);
  const [showGarageFrom, setShowGarageFrom] = useState(false);

  return (
    <>
      <div className="LoginSignup container-fluid">
        <div className="LoginSignup-container" style={{ width: "550px" }}>
          {!showGarageFrom && (
            <>
              {showLogin ? (
                <LoginForm handleToggleCard={handleToggleCard} />
              ) : (
                <SignupForm handleToggleCard={handleToggleCard} />
              )}
              <div
                className="sign-up-garage"
                onClick={() => setShowGarageFrom(true)}
              >
                <button className="btn btn-outline-dark">
                  Sign Up as Garage
                </button>
              </div>
            </>
          )}
          {showGarageFrom && (
            <SignupGarageForm
              handleToggleCard={() => setShowGarageFrom(false)}
            />
          )}
        </div>
      </div>
    </>
  );
}

export default LoginSignup;
