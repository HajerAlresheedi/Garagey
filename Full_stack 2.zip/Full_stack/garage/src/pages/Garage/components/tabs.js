import React, { useState } from "react";
import ServiceTab from "./tabs-content/ServiceTab";
import ReviewsTab from "./tabs-content/ReviewsTab";
import GarageInfoTab from "./tabs-content/GarageInfoTab";
import "./tabs.css";
function Tabs({ data }) {
  const [activeTab, setActiveTab] = useState(1);

  const handleTabClick = (tabNumber) => {
    setActiveTab(tabNumber);
  };

  const tabsData = [
    { id: 1, label: "Services", content: <ServiceTab storeName={data.name} /> },
    { id: 2, label: "Reviews", content: <ReviewsTab /> },
    { id: 3, label: "Garage Info", content: <GarageInfoTab /> },
  ];

  return (
    <div className="container mt-5">
      <ul className="nav nav-tabs">
        {tabsData.map((tab) => (
          <li className="nav-item" key={tab.id}>
            <button
              className={`nav-link ${activeTab === tab.id ? "active" : ""}`}
              onClick={() => handleTabClick(tab.id)}
            >
              {tab.label}
            </button>
          </li>
        ))}
      </ul>

      <div className="tab-content mt-3 mb-4">
        {tabsData.map((tab) => (
          <div
            key={tab.id}
            className={`tab-pane fade ${
              activeTab === tab.id ? "show active" : ""
            }`}
          >
            {tab.content}
          </div>
        ))}
      </div>
    </div>
  );
}

export default Tabs;
