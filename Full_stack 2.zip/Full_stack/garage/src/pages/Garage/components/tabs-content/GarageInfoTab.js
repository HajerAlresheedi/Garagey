import React from "react";

const GarageInfoTab = () => {
  const garageInfo = {
    name: "John's Auto Repair",
    location: "123 Main St, Cityville",
    contactNumber: "555-1234",
    email: "johnsautorepair@example.com",
    about: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed...",
  };

  return (
    <div className="container">
      <h2 className="mt-4 mb-3">Garage Information</h2>
      <dl className="row">
        <dt className="col-sm-3">Name:</dt>
        <dd className="col-sm-9">{garageInfo.name}</dd>

        <dt className="col-sm-3">Location:</dt>
        <dd className="col-sm-9">{garageInfo.location}</dd>

        <dt className="col-sm-3">Contact Number:</dt>
        <dd className="col-sm-9">{garageInfo.contactNumber}</dd>

        <dt className="col-sm-3">Email:</dt>
        <dd className="col-sm-9">{garageInfo.email}</dd>

        <dt className="col-sm-3">About:</dt>
        <dd className="col-sm-9">{garageInfo.about}</dd>
      </dl>
    </div>
  );
};

export default GarageInfoTab;
