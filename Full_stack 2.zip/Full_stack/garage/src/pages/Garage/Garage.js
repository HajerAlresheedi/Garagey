import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { Garages } from "../../components/Popular/data";
import { FaStar, FaRegStar } from "react-icons/fa";
import Tabs from "./components/tabs";

function Garage() {
  const [garageData, setGarageData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const navigate = useNavigate();
  const params = useParams();
  const data = Garages;

  useEffect(() => {
    const fetchData = async () => {
      try {
        const garage = data.find((garage) => garage.id === parseInt(params.id));

        if (garage) {
          setGarageData(garage);
        } else {
          setError("Garage not found");
        }
      } catch (error) {
        setError("Error fetching garage data");
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [params, data, navigate]);

  if (loading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>Error: {error}</div>;
  }

  return (
    <>
      <div className="container mt-5">
        <div
          className="row border p-3 m-auto  mt-2 mb-5"
          style={{ width: "fit-content" }}
        >
          <div className="col-lg-6 col-md-12 mb-3">
            <div className="d-flex justify-content-end h-100">
              <img
                src={garageData.image}
                alt={garageData.name}
                className="border"
              />
            </div>
          </div>
          <div className="col-lg-6 col-md-12">
            <h1 className="mb-4">{garageData.name}</h1>
            <div className="mb-3"> {garageData.GarageType.join(", ")}</div>
            <div className="mb-3">{renderRatingStars(garageData.ritting)}</div>
            <div className="mb-3 text-success">
              {garageData.state === "open" ? "Open" : "Closed"}
            </div>
          </div>
        </div>
      </div>
      <Tabs data={garageData} />
    </>
  );
}

const renderRatingStars = (rating) => {
  const stars = [];
  const roundedRating = Math.round(rating);

  for (let i = 1; i <= 5; i++) {
    if (i <= roundedRating) {
      stars.push(<FaStar key={i} className="text-warning" />);
    } else {
      stars.push(<FaRegStar key={i} className="text-warning" />);
    }
  }

  return stars;
};

export default Garage;
