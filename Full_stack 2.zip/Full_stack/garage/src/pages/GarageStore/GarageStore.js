import React from "react";
import Popular from "../../components/Garages/Popular";
const GarageStore = () => {
  return (
    <div>
      <Popular />
    </div>
  );
};

export default GarageStore;
