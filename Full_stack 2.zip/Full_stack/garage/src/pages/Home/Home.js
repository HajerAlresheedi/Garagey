import React from "react";
import Popular from "../../components/Popular/Popular";
import Header from "../../components/Header/Header";
import GarageTypesPage from "../../components/GarageTypes/page";
const Home = () => {
  return (
    <div>
      <Header />
      <hr className="mt-3 mb-3 w-80 m-auto" />
      <div className="p-1">
        <GarageTypesPage />
      </div>
      <hr className="mb-3 w-80 m-auto" />
      <Popular />
    </div>
  );
};

export default Home;
