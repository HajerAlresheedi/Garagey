import React from "react";
import "./filter-dailog.css";
const FilterDialog = ({ onClose, onApply }) => {
  return (
    <div className="filter-dialog">
      <div className="filter-content">
        <p>Filter options go here</p>
        <button className="btn btn-primary" onClick={onApply}>
          Apply Filter
        </button>
      </div>
      <button className="btn btn-outline-secondary close-btn" onClick={onClose}>
        Close
      </button>
    </div>
  );
};

export default FilterDialog;
