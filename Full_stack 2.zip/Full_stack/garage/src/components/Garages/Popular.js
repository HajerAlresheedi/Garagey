import React, { useState } from "react";
import "./Pop.css";
import { Garages } from "./data";
import GarageCard from "../GarageCard/GarageCard";
import FilterDialog from "./Filter-dailog";
import { BiFilter } from "react-icons/bi";


const Popular = () => {
  const [showFilter, setShowFilter] = useState(false);

  const toggleFilter = () => {
    setShowFilter(!showFilter);
  };

  const handleFilterApply = () => {
    setShowFilter(false);
  };

  const handleFilterClose = () => {
    setShowFilter(false);
  };

  return (
    <div
      className="container my-4 Popular h-100"
      style={{ overflow: "hidden" }}
    >
      <div
        className="d-flex justify-content-end mb-3 w-100"
        style={{ padding: "0 25px" }}
      >
        <button className="btn btn-outline-secondary" onClick={toggleFilter}>
          <BiFilter />
        </button>
      </div>
      <h2 className="text-center mb-4">Popular Garages</h2>
      <div
        className="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-4 g-4"
        style={{ padding: "0 20px" }}
      >
        {Garages.map((garage, index) => (
          <div key={index} className="col mb-3">
            <GarageCard {...garage} />
          </div>
        ))}
      </div>

      {showFilter && (
        <FilterDialog onClose={handleFilterClose} onApply={handleFilterApply} />
      )}
    </div>
  );
};

export default Popular;
