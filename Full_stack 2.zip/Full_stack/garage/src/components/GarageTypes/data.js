export const garageTypes = [
  {
    id: 1,
    label: "Car Repair",
    image: "https://source.unsplash.com/300x200/?garage-car-repair",
  },
  {
    id: 2,
    label: "Tire Service",
    image: "https://source.unsplash.com/300x200/?garage-tire-service",
  },
  {
    id: 3,
    label: "Oil Change",
    image: "https://source.unsplash.com/300x200/?garage-oil-change",
  },
  {
    id: 4,
    label: "Brake Inspection",
    image: "https://source.unsplash.com/300x200/?garage-brake-inspection",
  },
  {
    id: 5,
    label: "Transmission Service",
    image: "https://source.unsplash.com/300x200/?garage-transmission-service",
  },
  {
    id: 6,
    label: "Battery Replacement",
    image: "https://source.unsplash.com/300x200/?garage-battery-replacement",
  },
  {
    id: 7,
    label: "Alignment Service",
    image: "https://source.unsplash.com/300x200/?garage-alignment-service",
  },
  {
    id: 8,
    label: "Diagnostic Check",
    image: "https://source.unsplash.com/300x200/?garage-diagnostic-check",
  },
  {
    id: 9,
    label: "Air Conditioning Service",
    image:
      "https://source.unsplash.com/300x200/?garage-air-conditioning-service",
  },
  {
    id: 10,
    label: "Exhaust System Repair",
    image: "https://source.unsplash.com/300x200/?garage-exhaust-system-repair",
  },
  {
    id: 11,
    label: "Wheel Alignment",
    image: "https://source.unsplash.com/300x200/?garage-wheel-alignment",
  },
  {
    id: 12,
    label: "Suspension Repair",
    image: "https://source.unsplash.com/300x200/?garage-suspension-repair",
  },
];
