import React, { useState, useEffect } from "react";
import "./Navbarr.css";
import logo from "../Assets/img/logo.jpg";
import walletp from "../Assets/img/Wallet.png";
import { NavLink, useNavigate } from "react-router-dom";

const Navbarr = () => {
  const [userData, setUserData] = useState(false);
  const [cartLength, setCartLength] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const storedUserData = localStorage.getItem("userData");
    const cart = JSON.parse(localStorage.getItem("cart"));
    if (cart) {
      setCartLength(cart.length);
    }
    if (storedUserData) {
      setUserData(JSON.parse(storedUserData));
    }
  }, [cartLength, navigate]);

  const handleLogout = () => {
    localStorage.removeItem("userData");
    setUserData(null);
    navigate("/");
  };

  return (
    <nav className="navbar navbar-expand-lg navbar-light bg-light p-3">
      <NavLink className="navbar-brand" to="/">
        <img src={logo} alt="GARAGEY" height="40" />
      </NavLink>
      <button
        className="navbar-toggler"
        type="button"
        data-bs-toggle="collapse"
        data-bs-target="#navbarNav"
        aria-controls="navbarNav"
        aria-expanded="false"
        aria-label="Toggle navigation"
      >
        <span className="navbar-toggler-icon"></span>
      </button>
      <div className="collapse navbar-collapse" id="navbarNav">
        {
          <ul className="navbar-nav mx-auto">
            <li className="nav-item">
              <NavLink className="nav-link" to="/">
                Home
              </NavLink>
            </li>
            {userData && userData.type === "user" && (
              <li className="nav-item">
                <NavLink className="nav-link" to="/Reservation">
                  Reservation{" "}
                  {userData && cartLength > 0 && <span> ({cartLength}) </span>}
                </NavLink>
              </li>
            )}
            {userData && userData.type === "user" && (
              <li className="nav-item">
                <NavLink className="nav-link" to="/Garages">
                  Garages
                </NavLink>
              </li>
            )}
            <li className="nav-item">
              {userData && (
                <NavLink className="nav-link" to="/Settings">
                  {userData.type === "garage" ? "Dashboard" : "Settings"}
                </NavLink>
              )}
            </li>
          </ul>
        }
        <div className="nav-login-cart">
          {userData ? (
            <button className="btn btn-outline-dark" onClick={handleLogout}>
              Log out
            </button>
          ) : (
            <NavLink to="/LoginSignup">
              <button className="btn btn-outline-dark">Sign Up</button>
            </NavLink>
          )}
          {userData && userData.type === "user" && (
            <NavLink to="/wallet">
              <img src={walletp} alt="Wallet" height="30" />
            </NavLink>
          )}
        </div>
      </div>
    </nav>
  );
};

export default Navbarr;
