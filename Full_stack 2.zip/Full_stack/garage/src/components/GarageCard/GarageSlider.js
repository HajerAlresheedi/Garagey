import React, { useRef } from "react";
import { FaChevronLeft, FaChevronRight } from "react-icons/fa";
import "./GarageSlider.css";
import GarageCard from "./GarageCard";
// home last 
const GarageSlider = ({ Garages }) => {
  const sliderRef = useRef(null);
  const nextSlide = () => {
    const childWidth = sliderRef.current.firstElementChild.clientWidth;
    sliderRef.current.scrollLeft -= Math.abs(childWidth + 25);
  };

  const prevSlide = () => {
    const childWidth = sliderRef.current.firstElementChild.clientWidth;
    sliderRef.current.scrollLeft += Math.abs(childWidth - 25);
  };

  return (
    <div className="card-slider">
      <div className="slider-container" ref={sliderRef}>
        {Garages.map((card, index) => (
          <div key={index} className="card-container">
            <GarageCard {...card} />
          </div>
        ))}
      </div>
      <button className="slider-btn prev-btn" onClick={prevSlide}>
        <FaChevronLeft />
      </button>
      <button className="slider-btn next-btn" onClick={nextSlide}>
        <FaChevronRight />
      </button>
    </div>
  );
};

export default GarageSlider;
