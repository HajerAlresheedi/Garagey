import React from "react";
import { FaStar } from "react-icons/fa";
import { Link } from "react-router-dom";
import "./GarageSlider.css";
const GarageCard = ({ image, name, GarageType, ritting, state, id }) => {
  return (
    <div className="card" style={{ height: "25rem" }}>
      <img
        src={image}
        className="card-img-top"
        alt={name}
        style={{ objectFit: "cover", height: "200px" }}
      />
      <div className="card-body d-grid">
        <h5 className="card-title">{name}</h5>
        <p className="card-text text-truncate">{GarageType.join(", ")}</p>
        <div className="d-flex justify-content-between align-items-center w-100 align-self-end">
          <p className="mb-0 rating gap-1">
            {ritting} <FaStar />
          </p>
          <span className="state">{state}</span>
        </div>
      </div>
      <Link to={`/Garages/${id}`} className="text-center p-2">
        <button className="btn btn-outline-dark">Make Order</button>
      </Link>
    </div>
  );
};

export default GarageCard;
