// import React from "react";
// import "./filter-dailog.css";
// const FilterDialog = ({ onClose, onApply }) => {// handle close and apply .
//   return (
//     <div className="filter-dialog">
//       <div className="filter-content">
//         <p>Filter options go here</p>
//         <button className="btn btn-primary" onClick={onApply}>
//           Apply Filter
//         </button>
//       </div>
//       <button className="btn btn-outline-secondary close-btn" onClick={onClose}>
//         Close
//       </button>
//     </div>
//   );
// };

// export default FilterDialog;
import React, { useState } from "react";
import Select from "react-select";
import { BiFilter, BiX } from "react-icons/bi";
import "./filter-dailog.css";

const FilterDialog = ({ onClose, onApply }) => {
  const [selectedGarageType, setSelectedGarageType] = useState("");

  const handleGarageTypeChange = (selectedOption) => {
    setSelectedGarageType(selectedOption);
  };

  const applyFilter = () => {
    onApply(selectedGarageType.value);
    onClose();
  };

  const allGarageTypes = [
    { value: "", label: "All Types" },
    { value: "auto repair", label: "Auto Repair" },
    { value: "car service", label: "Car Service" },
    { value: "transmission repair", label: "Transmission Repair" },
    { value: "tire rotation", label: "Tire Rotation" },
    { value: "electrical systems", label: "Electrical Systems" },
  ];

  return (
    <div className="filter-dialog">
      <div className="filter-content">
        <p>Filter options go here</p>
        <Select  //
          id="garageType"
          value={selectedGarageType}
          onChange={handleGarageTypeChange}
          options={allGarageTypes}
        />
        <button className="btn btn-primary mt-2" onClick={applyFilter}>
          Apply Filter <BiFilter />
        </button>
      </div>
      <button className="btn btn-outline-secondary close-btn" onClick={onClose}>
        Close <BiX />
      </button>
    </div>
  );
};

export default FilterDialog;