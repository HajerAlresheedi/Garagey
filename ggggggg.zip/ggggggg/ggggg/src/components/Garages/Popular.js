// import React, { useState } from "react";
// import "./Pop.css";
// import { Garages } from "./data";
// import GarageCard from "../GarageCard/GarageCard";
// import FilterDialog from "./Filter-dailog";
// import { BiFilter } from "react-icons/bi";
// // import Search from "../Search/Search.js";



// const Popular = () => {
//   const [showFilter, setShowFilter] = useState(false); //handel the showen of fillter

//   const toggleFilter = () => {
//     setShowFilter(!showFilter);
//   };

//   const handleFilterApply = () => {
//     setShowFilter(false);
//   };

//   const handleFilterClose = () => {
//     setShowFilter(false);
//   };

//   return (
//     <div
  
//       className="container my-4 Popular h-100"
//       style={{ overflow: "hidden" }}
//     >
//       <div
//         className="d-flex justify-content-end mb-3 w-100"
//         style={{ padding: "0 25px" }}
//       >
//         <button className="btn btn-outline-secondary" onClick={toggleFilter}>
//           <BiFilter />
//         </button>
//       </div>
//       <h2 className="text-center mb-4">Popular Garages</h2>
//       <div
//         className="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-4 g-4"
//         style={{ padding: "0 20px" }}
//       >
//         {Garages.map((garage, index) => (
//           <div key={index} className="col mb-3">
//             <GarageCard {...garage} />
//           </div>
//         ))}
//       </div>

//       {showFilter && (
//         <FilterDialog onClose={handleFilterClose} onApply={handleFilterApply} /> //when click Apply Filter and close (close the pop)      back here to make the filter? ?
//         //make the filterr based in the type of the garage????/??????????
//       )}
//     </div>
//   );
// };

// export default Popular;

import React, { useState } from "react";
// import "./Pop.css";
import { Garages } from "./data";
import GarageCard from "../GarageCard/GarageCard";
import FilterDialog from "./Filter-dailog";
import { BiFilter } from "react-icons/bi";

const Popular = () => {
  const [showFilter, setShowFilter] = useState(false);
  const [filterSettings, setFilterSettings] = useState({ garageType: "" });

  const toggleFilter = () => {
    setShowFilter(!showFilter);
  };

  const handleFilterApply = (selectedGarageType) => {
    setFilterSettings({ garageType: selectedGarageType });
  };

  const handleFilterClose = () => {
    setShowFilter(false);
  };

  const filteredGarages =
    filterSettings.garageType === ""
      ? Garages
      : Garages.filter((garage) => {
          if (
            garage &&
            garage.GarageType &&
            Array.isArray(garage.GarageType) &&
            garage.GarageType.length > 0
          ) {
            const lowercasedTypes = garage.GarageType.map((type) =>
              typeof type === "string" ? type.toLowerCase() : type
            );
            return (
              filterSettings.garageType &&
              lowercasedTypes.includes(filterSettings.garageType.toLowerCase())
            );
          } else {
            console.error("Invalid GarageType for Garage:", garage);
            return false;
          }
        });

  return (
    <div
      className="container my-4 Popular h-100"
      style={{ overflow: "hidden" }}
    >
      <div
        className="d-flex justify-content-end mb-3 w-100"
        style={{ padding: "0 25px" }}
      >
        <button className="btn btn-outline-secondary" onClick={toggleFilter}>
          <BiFilter />
        </button>
      </div>
      <h2 className="text-center mb-4">Popular Garages</h2>
      <div
        className="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-4 g-4"
        style={{ padding: "0 20px", minWidth: "100%" }}
      >
        {filteredGarages.map((garage, index) => (
          <div key={index} className="col mb-3">
            <GarageCard {...garage} />
          </div>
        ))}
      </div>
      {showFilter && (
        <FilterDialog onClose={handleFilterClose} onApply={handleFilterApply} />
      )}
    </div>
  );
};

export default Popular;
