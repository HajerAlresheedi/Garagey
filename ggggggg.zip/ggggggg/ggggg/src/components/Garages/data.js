import im from "../Assets/img/car3.png";
import im1 from "../Assets/img/E.jpg";
import im2 from "../Assets/img/car2.jpeg";
import im3 from "../Assets/img/G.jpg";
import im4 from "../Assets/img/ii.png";
import im5 from "../Assets/img/CAR.webp";
import im6 from "../Assets/img/M.webp";
import im7 from "../Assets/img/R.jpg";
import im8 from "../Assets/img/img.webp";
export const Garages = [
  {
    id: 1,
    name: "John’s Auto Repair",
    image: im,
    GarageType: ["Auto Repair", "Diagnostics"],
    rating: 4.8,
    state: "open",
  },
  {
    id: 2,
    name: "Mike’s Car Service",
    image: im1,
    GarageType: ["Car Service", "Oil Change"],
    rating: 4.2,
    state: "open",
  },
  {
    id: 3,
    name: "Sara’s Garage Center",
    image: im2,
    GarageType: ["Transmission Repair", "Brake Service"],
    rating: 4.5,
    state: "open",
  },
  {
    id: 4,
    name: "Bob’s Automotive Solutions",
    image: im3,
    GarageType: ["Tire Rotation", "Alignment"],
    rating: 4.0,
    state: "open",
  },
  {
    id: 5,
    name: "Alice’s Car Care",
    image: im4,
    GarageType: ["Electrical Systems", "Engine Diagnostics"],
    rating: 4.7,
    state: "open",
  },
  {
    id: 6,
    name: "Dave's Garage",
    image:im5,
    GarageType: ["Suspension Repair", "Wheel Balancing"],
    rating: 4.3,
    state: "open",
  },
  {
    id: 7,
    name: "Emily's Auto Shop",
    image: im6,
    GarageType: ["Exhaust Systems", "AC Repair"],
    rating: 4.6,
    state: "open",
  },
  {
    id: 8,
    name: "Frank's Car Fix",
    image: im6,
    GarageType: ["Engine Overhaul", "Cooling Systems"],
    rating: 4.2,
    state: "open",
  },
  {
    id: 9,
    name: "Gina's Garage Services",
    image: im6,
    GarageType: ["Wheel Alignment", "Oil Change"],
    rating: 4.5,
    state: "open",
  },
  {
    id: 10,
    name: "Henry's Auto Center",
    image: im2,
    GarageType: ["Transmission Service", "Brake Inspection"],
    rating: 4.8,
    state: "open",
  },
  {
    id: 11,
    name: "Ivy's Mechanic Workshop",
    image: im,
    GarageType: ["Tire Replacement", "Battery Check"],
    rating: 4.1,
    state: "open",
  },
  {
    id: 12,
    name: "Jack's Vehicle Solutions",
    image: im4,
    GarageType: ["Electrical Repairs", "Diagnostics"],
    rating: 4.4,
    state: "open",
  },
  {
    id: 13,
    name: "Katie's Car Care",
    image: im7,
    GarageType: ["Suspension Inspection", "Air Filter Replacement"],
    rating: 4.6,
    state: "open",
  },
  {
    id: 14,
    name: "Leo's Auto Service",
    image: im8,
    GarageType: ["Exhaust Repair", "Fluid Checks"],
    rating: 4.3,
    state: "open",
  },
  {
    id: 15,
    name: "Mia's Automotive Solutions",
    image: im8,
    GarageType: ["Fuel System Cleaning", "Spark Plug Replacement"],
    rating: 4.7,
    state: "open",
  },
];
