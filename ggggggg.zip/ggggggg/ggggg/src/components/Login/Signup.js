import React from "react";
import { useState } from "react";
import { Multiselect } from "multiselect-react-dropdown";
import "../../pages/css/LoginSignup.css";

function Signup() {
  const data = [  //object cars options
    { Cars: "Hatchback", id: 1 },
    { Cars: "Minivan", id: 2 },
    { Cars: "Convertible", id: 3 },
    { Cars: "Sedan", id: 4 },
    { Cars: "Crossover", id: 5 },
    { Cars: "Cadillac", id: 6 },
    { Cars: "Van", id: 7 },
  ];

  const [options] = useState(data); //state for option
  return (
    <main>
      <div className="LoginSignup">
        <div className="LoginSignup-container"></div>
        <h1>Sign Up</h1>
        <div className="LoginSignup-fields">
          <input type="text" placeholder="Your Name" />
          <input type="email" placeholder="Email Address" />
          <input type="password" placeholder="Password" />

          <div className="Dropdown">
            <h3>Add Your Care</h3>
            <Multiselect options={options} displayValue="Cars" />
          </div>
        </div>
      </div>
    </main>
  );
}

export default Signup;
