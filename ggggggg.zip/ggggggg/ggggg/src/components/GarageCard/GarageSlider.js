import React, { useRef } from "react";
import { FaChevronLeft, FaChevronRight } from "react-icons/fa"; //react icons
import "./GarageSlider.css";
import GarageCard from "./GarageCard";
// home page last 
const GarageSlider = ({ Garages }) => { //take prop (array of garages )
  const sliderRef = useRef(null); //create a reference to the slider 
  const nextSlide = () => { //handle the scrolling the slider 
    const childWidth = sliderRef.current.firstElementChild.clientWidth;
    sliderRef.current.scrollLeft -= Math.abs(childWidth + 25);
  };

  const prevSlide = () => {
    const childWidth = sliderRef.current.firstElementChild.clientWidth;
    sliderRef.current.scrollLeft += Math.abs(childWidth - 25);
  };

  return (
    <div className="card-slider">
      <div className="slider-container" ref={sliderRef}>
        {Garages.map((card, index) => (   //index of array
          <div key={index} className="card-container">{/* every garage object in the array creat div card-container */}
            <GarageCard {...card} />
          </div>
        ))}
      </div>
      <button className="slider-btn prev-btn" onClick={prevSlide}>
        <FaChevronLeft />
      </button>
      <button className="slider-btn next-btn" onClick={nextSlide}>
        <FaChevronRight />
      </button>
    </div>
  );
};

export default GarageSlider;
