import React from "react";
import "./Pop.css";
import { Garages } from "./data";
import GarageSlider from "../GarageCard/GarageSlider";

const Popular = () => {
  return (
    <div className="Popular">
      <GarageSlider Garages={Garages} />
    </div>
  );
};

export default Popular;
