import React from "react";
import { Container, Card } from "react-bootstrap";
import "./GarageTypesPage.css";
import { garageTypes } from "./data";
import { Link } from "react-router-dom";
const GarageTypesPage = () => {
  return (
    <Container>
      <h1>Garage Types</h1>

      <div className="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-4">
        {garageTypes.map((garageType) => ( //mapping for every garage type and creat a cord for each 
          <div key={garageType.id} className="col mb-4">
            <Card className="garage-card">
              <Card.Img variant="top" src={garageType.image} />
              <div className="glass-overlay">
                <Card.Body>
                  <Link
                    to={"/" + garageType.id}
                    className="d-flex gap-1 align-items-center text-light"
                  >
                    <Card.Title>{garageType.label}</Card.Title> {/*the title is the type of garages */}
                  </Link>
                </Card.Body>
              </div>
            </Card>
          </div>
        ))}
      </div>
    </Container>
  );
};

export default GarageTypesPage;
