import im from "../Assets/img/car3.png";
import im1 from "../Assets/img/E.jpg";
import im2 from "../Assets/img/car2.jpeg";
import im3 from "../Assets/img/G.jpg";
import im4 from "../Assets/img/ii.png";
import im5 from "../Assets/img/CAR.webp";
import im6 from "../Assets/img/M.webp";
import im7 from "../Assets/img/R.jpg";
import im8 from "../Assets/img/img.webp";

export const garageTypes = [
  {
    id: 1,
    label: "Car Repair",
    image: im,
  },
  {
    id: 2,
    label: "Tire Service",
    image: im1,
  },
  {
    id: 3,
    label: "Oil Change",
    image: im2,
  },
  {
    id: 4,
    label: "Brake Inspection",
    image: im3,
  },
  {
    id: 5,
    label: "Transmission Service",
    image: im4,
  },
  {
    id: 6,
    label: "Battery Replacement",
    image: im5,
  },
  {
    id: 7,
    label: "Alignment Service",
    image: im6,
  },
  {
    id: 8,
    label: "Diagnostic Check",
    image: im7,
  },
  {
    id: 9,
    label: "Air Conditioning Service",
    image: im8,
  },
  {
    id: 10,
    label: "Exhaust System Repair",
    image: im,
  },
  {
    id: 11,
    label: "Wheel Alignment",
    image: im7,
  },
  {
    id: 12,
    label: "Suspension Repair",
    image: im3,
  },
];
