import React from "react";
import "./Footer.css";

const Footer = () => {
  return (
    <>
      <footer className="py-4 bg-dark text-white-50">
        <div className="container text-center">
          <small>&copy; 2023 GARAGEY. All rights reserved.</small>
        </div>
      </footer>
      {/* </div> */}
    </>
  );
};

export default Footer;
