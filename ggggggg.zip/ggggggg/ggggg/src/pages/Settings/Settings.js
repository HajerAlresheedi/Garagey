import React from "react";
import UserDashboard from "./Dashboards/UserDashboard";
import GarageDashboard from "./Dashboards/GarageDashboard";
import "./SettingsStyle.css";
//go to UserDashboard or GarageDashboard

export default function Settings() {
  const userData = JSON.parse(localStorage.getItem("userData")) || {};
  const userType = userData.type || "";
  return (
    <div>{userType === "user" ? <UserDashboard /> : <GarageDashboard />}</div>
  );
}
