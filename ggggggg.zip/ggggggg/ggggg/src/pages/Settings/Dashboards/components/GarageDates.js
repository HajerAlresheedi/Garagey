import React, { useState, useEffect } from "react";
import { Calendar, momentLocalizer } from "react-big-calendar";
import moment from "moment";
import "react-big-calendar/lib/css/react-big-calendar.css";

const localizer = momentLocalizer(moment);

//random color
const generateRandomHexColor = () => {
  const letters = "0123456789ABCDEF";
  let color = "#";
  for (let i = 0; i < 6; i++) {
    color += letters[Math.floor(Math.random() * 16)];
  }
  return color;
};

const MyCalendar = () => {
  const initialData = [
    { day: "Monday", date: "2023-12-12", hour: "8", customers: "rawan, hajer" },
    { day: "Monday", date: "2023-12-12", hour: "15", customers: "Adel, maryam" },
    { day: "Sunday", date: "2023-12-14", hour: "10", customers: "rana, Anour" },
    {
      day: "Wednesday",
      date: "2023-12-22",
      hour: "12",
      customers: "Bob, Kate",
    },
  ];

  const [eventData, setEventData] = useState(initialData);

  useEffect(() => {
    setEventData((prevData) =>
      prevData.map((event) => ({
        ...event,
        color: generateRandomHexColor(),
      }))
    );
  }, []);

  const eventStyleGetter = (event, start, end, isSelected) => {
    return {
      style: {
        backgroundColor: event.color,
        color: "white",
        fontWeight: "semibold",
      },
    };
  };

  return (
    <div style={{ height: "100vh" }}>
      <Calendar
        localizer={localizer}
        events={eventData}
        views={["month", "week", "day"]}
        step={60}
        showMultiDayTimes
        defaultDate={new Date()}
        titleAccessor={(event) => event.customers}
        startAccessor={(event) =>
          moment(event.date + " " + event.hour, "YYYY-MM-DD H").toDate()
        }
        endAccessor={(event) =>
          moment(event.date + " " + event.hour, "YYYY-MM-DD H")
            .add(1, "hour")
            .toDate()
        }
        eventPropGetter={eventStyleGetter}
      />
    </div>
  );
};

export default MyCalendar;
