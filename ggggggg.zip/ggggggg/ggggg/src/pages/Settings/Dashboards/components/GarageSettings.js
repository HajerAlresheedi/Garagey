import React, { useState, useEffect } from "react";
import { Form, Container, Row, Col, Button, Image } from "react-bootstrap";
import { BsPencilSquare, BsCheck, BsX } from "react-icons/bs";

const GarageSettings = ({ onClose }) => {
  const [garageData, setGarageData] = useState({
    image: "",
    storeName: "",
    type: "",
    location: "",
    description: "",
    email: "",
    phoneNumber: "",
  });
  const [oldPassword, setOldPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmNewPassword, setConfirmNewPassword] = useState("");
  const [isEditing, setIsEditing] = useState(false);
  const [error, setError] = useState("");
  const [changePassword, setChangePassword] = useState(false);
  const [selectedImage, setSelectedImage] = useState(null);

  useEffect(() => {
    // Get data from local storage
    const storedGarageData = JSON.parse(localStorage.getItem("userData")) || {};

    // Set initial state
    setGarageData(storedGarageData);
  }, []);

  const handleEditClick = () => {
    setIsEditing(true);
    setError("");
  };

  const handleSaveClick = () => {
    // Handle save logic here

    // Save data to local storage
    localStorage.setItem("userData", JSON.stringify(garageData));

    setIsEditing(false);
  };

  const handleCancelClick = () => {
    setOldPassword("");
    setNewPassword("");
    setConfirmNewPassword("");
    setIsEditing(false);
    setError("");
  };

  const handleChange = (e) => {
    setGarageData({ ...garageData, [e.target.name]: e.target.value });
  };

  const handlePasswordChange = () => {
    setChangePassword(!changePassword);
  };

  const handleImageChange = (e) => {
    const file = e.target.files[0];

    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedImage(reader.result);
        setGarageData({ ...garageData, image: reader.result });
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <Container className="mt-4 settings">
      <h2 className="mb-4">Settings</h2>
      <Form>
        <Row className="mb-3">
          <Col sm>
            <Form.Group controlId="formImage">
              <Form.Label>Image</Form.Label>
              <div>
                <div className="my-2">
                  {selectedImage ? (
                    <Image
                      src={selectedImage}
                      alt="Store Image"
                      fluid
                      style={{ width: 250 }}
                    />
                  ) : (
                    <Image
                      src={garageData.image}
                      alt="Store Image"
                      fluid
                      style={{ width: 250 }}
                    />
                  )}
                </div>
                {isEditing && (
                  <div>
                    <Form.Control
                      type="file"
                      accept="image/*"
                      onChange={handleImageChange}
                      className="my-2"
                    />
                    <Button
                      variant="info"
                      className="my-2"
                      onClick={() => setSelectedImage(null)}
                    >
                      Update Image
                    </Button>
                  </div>
                )}
              </div>
            </Form.Group>
          </Col>
        </Row>
        <Row className="mb-3">
          <Col sm>
            <Form.Group controlId="formStoreName">
              <Form.Label>Store Name</Form.Label>
              <Form.Control
                type="text"
                placeholder="Enter store name"
                name="storeName"
                value={garageData.storeName}
                onChange={handleChange}
                disabled={!isEditing}
              />
            </Form.Group>
          </Col>
          <Col sm>
            <Form.Group controlId="formType">
              <Form.Label>Type</Form.Label>
              <Form.Control
                type="text"
                placeholder="Enter type"
                name="type"
                value={garageData.type}
                onChange={handleChange}
                disabled={!isEditing}
              />
            </Form.Group>
          </Col>
        </Row>
        <Row className="mb-3">
          <Col sm>
            <Form.Group controlId="formLocation">
              <Form.Label>Location</Form.Label>
              <Form.Control
                type="text"
                placeholder="Enter location"
                name="location"
                value={garageData.location}
                onChange={handleChange}
                disabled={!isEditing}
              />
            </Form.Group>
          </Col>
          <Col sm>
            <Form.Group controlId="formDescription">
              <Form.Label>Description</Form.Label>
              <Form.Control
                type="text"
                placeholder="Enter description"
                name="description"
                value={garageData.description}
                onChange={handleChange}
                disabled={!isEditing}
              />
            </Form.Group>
          </Col>
        </Row>
        <Row className="mb-3">
          <Col sm>
            <Form.Group controlId="formEmail">
              <Form.Label>Email</Form.Label>
              <Form.Control
                type="email"
                placeholder="Enter email"
                name="email"
                value={garageData.email}
                onChange={handleChange}
                disabled={!isEditing}
              />
            </Form.Group>
          </Col>
          <Col sm>
            <Form.Group controlId="formPhoneNumber">
              <Form.Label>Phone Number</Form.Label>
              <Form.Control
                type="tel"
                placeholder="Enter phone number"
                name="phoneNumber"
                value={garageData.phoneNumber}
                onChange={handleChange}
                disabled={!isEditing}
              />
            </Form.Group>
          </Col>
        </Row>
        {changePassword && (
          <>
            <Row className="mb-3">
              <Col sm>
                <Form.Group controlId="formOldPassword">
                  <Form.Label>Old Password</Form.Label>
                  <Form.Control
                    type="password"
                    placeholder="Enter old password"
                    name="oldPassword"
                    value={oldPassword}
                    onChange={(e) => setOldPassword(e.target.value)}
                  />
                </Form.Group>
              </Col>
              <Col sm>
                <Form.Group controlId="formNewPassword">
                  <Form.Label>New Password</Form.Label>
                  <Form.Control
                    type="password"
                    placeholder="Enter new password"
                    name="newPassword"
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                  />
                </Form.Group>
              </Col>
              <Col sm>
                <Form.Group controlId="formConfirmNewPassword">
                  <Form.Label>Confirm New Password</Form.Label>
                  <Form.Control
                    type="password"
                    placeholder="Confirm new password"
                    name="confirmNewPassword"
                    value={confirmNewPassword}
                    onChange={(e) => setConfirmNewPassword(e.target.value)}
                  />
                </Form.Group>
              </Col>
            </Row>
          </>
        )}
        {error && <div className="text-danger">{error}</div>}
        <Row>
          <Col>
            {isEditing ? (
              <>
                <div className="my-2">
                  <Button onClick={handlePasswordChange} variant="outline-info">
                    <BsPencilSquare className="ms-1" /> password
                  </Button>
                </div>

                <Button
                  variant="success"
                  onClick={handleSaveClick}
                  className="me-2"
                >
                  <BsCheck className="mb-1" /> Save
                </Button>
                <Button variant="secondary" onClick={handleCancelClick}>
                  <BsX className="mb-1" /> Cancel
                </Button>
              </>
            ) : (
              <>
                <div className="d-flex align-items-center justify-content-between">
                  <Button variant="primary" onClick={handleEditClick}>
                    <BsPencilSquare className="mb-1" /> Edit
                  </Button>
                  <Button variant="secondary" onClick={onClose}>
                    {" "}
                    cancel
                  </Button>
                </div>
              </>
            )}
          </Col>
        </Row>
      </Form>
    </Container>
  );
};

export default GarageSettings;
