import React, { useState, useEffect } from "react";
import { Button, Form, Table, Alert, Row, Col } from "react-bootstrap";
import { BsPlus, BsPlusLg, BsTrash } from "react-icons/bs";
import { IoSettingsOutline } from "react-icons/io5";
import Select from "react-select";
import GarageSettings from "./components/GarageSettings";
import GarageDates from "./components/GarageDates";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";

const GarageDashboard = () => {
  const [showForm, setShowForm] = useState(false);
  const [showTable, setShowTable] = useState(true);
  const [showRequiredMessage, setShowRequiredMessage] = useState(false);  //to control the visibility
  const [customerNumber, setCustomerNumber] = useState("");
  const [serviceName, setServiceName] = useState("");
  const [price, setPrice] = useState("");
  const [description, setDescription] = useState("");
  const [duration, setDuration] = useState(""); //save data of service of garage 
  const [availabilitySlots, setAvailabilitySlots] = useState([]);
  const [selectedDate, setSelectedDate] = useState(null);
  const [selectedHours, setSelectedHours] = useState([]);
  const [editingServiceId, setEditingServiceId] = useState(null); //ID of service
  const [showGarageSettings, setShowGarageSettings] = useState(false);
  const [showGarageDates, setShowGarageDates] = useState(false); //Control the visibility
  const [servicesData, setServicesData] = useState([]); //Control the visibility

  useEffect(() => { //load the servicesData from localStorage 
    const storedData = localStorage.getItem("userData"); 
    if (storedData) {
      setServicesData(JSON.parse(storedData).services || []);
    }
  }, []);
  const updateLocalStorage = (newServicesData) => {  //updates the localStorage with the latest services data.
    localStorage.setItem(
      "userData",
      JSON.stringify({ services: newServicesData })
    );
  };
  const handleRemoveAvailabilitySlot = (index) => {  //removes an availability slot from the array.
    const updatedAvailabilitySlots = [...availabilitySlots];
    updatedAvailabilitySlots.splice(index, 1);
    setAvailabilitySlots(updatedAvailabilitySlots);
  };

  const handleAddAvailabilitySlot = () => { //Adds a new availability slot to the array.
    if (selectedDate && selectedHours.length > 0) {
      const newSlot = {
        day: selectedDate.toDateString(),
        hours: selectedHours,
      };

      setAvailabilitySlots([...availabilitySlots, newSlot]);
      setSelectedDate(null);
      setSelectedHours([]);
    }
  };

  const handleAddService = async () => {  //Validates and adds a new service to the servicesData array.
    if (
      !serviceName ||
      !price ||
      !description ||
      !duration ||
      !customerNumber ||
      availabilitySlots.length === 0
    ) {
      setShowRequiredMessage(true);
      return;
    }

    const newService = { //Update Service Data
      serviceName,
      price,
      description,
      duration,
      customerNumber,
      availability: availabilitySlots,
    };

    updateLocalStorage([...servicesData, newService]); //add the new server to  Local Storage: 

    setServicesData([...servicesData, newService]);
    setServiceName("");
    setPrice("");
    setDescription("");
    setDuration("");
    setCustomerNumber("");
    setAvailabilitySlots([]);
    setShowRequiredMessage(false);
    handleSwitchToTable(); //to go to table of servees
  };
//to toggle between two states  (showTable and showGarageSetting)
  const handelSwitchSettings = () => {  //??
    setShowTable((p) => !p);   //take the prev value of show table  and (not)
    setShowGarageSettings((prev) => !prev);
  };

  const handleUpdateService = () => {  //the all input requred 
    if (
      !serviceName ||
      !price ||
      !description ||
      !duration ||
      !customerNumber ||
      availabilitySlots.length === 0 ||
      !editingServiceId
    ) {
      setShowRequiredMessage(true); // show alert 
      return;
    }
//updatedServicesData  nwe array change the server that updated to the new and other services same whithout any change
//2
//to update the serveses 
    const updatedServicesData = servicesData.map((service) => { //mapping in serves data
      if (service === editingServiceId) { //current service being iterated is the one that is being edited ?
        return {            //تحديث
          ...service,
          serviceName,
          price,
          description,
          duration,
          customerNumber,
          availability: availabilitySlots,
        };
      }
      return service; //else
    });

    updateLocalStorage(updatedServicesData);

    setServicesData(updatedServicesData);
    setServiceName("");
    setPrice("");
    setDescription("");
    setDuration("");
    setCustomerNumber("");
    setAvailabilitySlots([]);
    setEditingServiceId(null);
    setShowRequiredMessage(false);
    handleSwitchToTable();
  };
//1
  const handleEditService = (service) => { //Editing 
    setShowForm(true);  //show editing a service
    setShowTable(false);  //hide the table 
    setEditingServiceId(service);
    setServiceName(service.serviceName);
    setPrice(service.price);
    setDescription(service.description);
    setDuration(service.duration);
    setCustomerNumber(service.customerNumber);
    setAvailabilitySlots(service.availability);
  };

  const handleSwitchToForm = () => { 
    setShowForm(true);
    setShowTable(false);
  };

  const handleSwitchToTable = () => { 
    setShowForm(false);
    setShowTable(true);
  };

  const handleShowGarageDates = () => {
    setShowTable((p) => !p);
    setShowGarageDates((prev) => !prev);
  };
  //removing a service from the table (garage)
  //it filters the current servicesData array to create a new array without the specified service
  const handleDeleteService = async (service) => {
    const updatedServicesData = servicesData.filter((src) => src !== service); //new array called updatedServicesData remove the spicfice server //it chick in every element in the array
    updateLocalStorage(updatedServicesData); //updated services data to local storage.
    setServicesData(updatedServicesData);  //removing the service that was deleted.
  };

  return (
    <div className="container height-fix my-2">
      {showRequiredMessage && (
        <Alert
          variant="danger"
          onClose={() => setShowRequiredMessage(false)}
          dismissible
        >
          Please fill in all required fields.
        </Alert>
      )}
      {showForm && (
        <Form>
          <Row>
            <Col>
              <Form.Group controlId="serviceName">
                <Form.Label>Service Name</Form.Label>
                <Form.Control
                  type="text"
                  placeholder="Enter service name"
                  value={serviceName}
                  onChange={(e) => setServiceName(e.target.value)}
                />
              </Form.Group>
            </Col>
            <Col>
              <Form.Group controlId="price">
                <Form.Label>Price</Form.Label>
                <Form.Control
                  type="number"
                  placeholder="Enter price"
                  value={price}
                  onChange={(e) => setPrice(e.target.value)}
                />
              </Form.Group>
            </Col>
          </Row>
          <Row>
            <Col>
              <Form.Group controlId="customerNumber">
                <Form.Label>Customer Number</Form.Label>
                <Form.Control
                  type="number"
                  placeholder="Enter customer number"
                  value={customerNumber}
                  onChange={(e) => setCustomerNumber(e.target.value)}
                />
              </Form.Group>
            </Col>
            <Col>
              <Form.Group controlId="duration">
                <Form.Label>Duration</Form.Label>
                <Form.Control
                  type="number"
                  placeholder="Enter duration"
                  value={duration}
                  onChange={(e) => setDuration(e.target.value)}
                />
              </Form.Group>
            </Col>
          </Row>
          <Row>
            <Col>
              <Form.Group controlId="description">
                <Form.Label>Description</Form.Label>
                <Form.Control
                  as="textarea"
                  rows={3}
                  placeholder="Enter service description"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                />
              </Form.Group>
            </Col>
          </Row>
          <Form.Group controlId="availability">
            <Form.Label>Availability</Form.Label>
            <Row>
              <Col>
                <DatePicker
                  selected={selectedDate}
                  onChange={(date) => setSelectedDate(date)}
                  placeholderText="Select date"
                  dateFormat="MMMM d, yyyy"
                  className="form-control"
                />
              </Col>
              <Col>
                <Select
                  isMulti //multi option 
                  className="select-container"
                  placeholder="Select hours"
                  options={Array.from({ length: 12 }, (_, i) => i + 8).map(
                    (hour) => ({
                      value: hour,
                      label: `${hour}:00`,
                    })
                  )}
                  onChange={(selectedOptions) =>  
                    setSelectedHours(
                      selectedOptions.map((option) => option.value)
                    )
                  }
                />
              </Col>
              <Col>
                <Button
                  variant="info"
                  onClick={handleAddAvailabilitySlot}
                  className="me-2"
                >
                  <BsPlusLg />
                </Button>
              </Col>
            </Row>
            <div>
              {availabilitySlots.length > 0 && (
                <div className="mt-3">
                  <h5>Selected Availability:</h5>
                  <div className="d-flex flex-wrap">
                    {availabilitySlots.map((slot, index) => (
                      <Button
                        key={index}
                        variant="outline-info"
                        className="me-2 mb-2"
                        onClick={() => handleRemoveAvailabilitySlot(index)}
                      >
                        {`${slot.day} - ${slot.hours.join(", ")} `}
                        <BsTrash />
                      </Button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </Form.Group>
          <div className="my-3 d-flex align-items-center justify-content-between">
            {editingServiceId ? (
              <Button variant="primary" onClick={handleUpdateService}>
                Update Service
              </Button>
            ) : (
              <Button variant="primary" onClick={handleAddService}>
                Save Service
              </Button>
            )}
          </div>
        </Form>
      )}

      {showTable && (
        <div>
          <Button variant="outline-secondary" onClick={handleSwitchToForm}>
            <BsPlus /> Add Service
          </Button>
          <Button
            variant="outline-secondary"
            className="ms-2"
            onClick={handelSwitchSettings}
          >
            <IoSettingsOutline /> Garage Settings
          </Button>
          <Button
            variant="outline-secondary"
            className="ms-2"
            onClick={handleShowGarageDates}
          >
            <IoSettingsOutline /> Garage Dates
          </Button>
          <Table striped bordered hover className="mt-3">
            <thead>
              <tr>
                <th>ID</th>
                <th>Service Name</th>
                <th>Price</th>
                <th>Description</th>
                <th>Duration</th>
                <th>Availability</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {servicesData.map((service) => (
                <tr key={service.id}>
                  <td>{service.id}</td>
                  <td>{service.serviceName}</td>
                  <td>{service.price}</td>
                  <td>{service.description}</td>
                  <td>{service.duration}</td>
                  <td>
                    {service.availability.length > 0 && (
                      <ul>
                        {service.availability.map((slot, index) => (
                          <li key={index}>
                            {slot.day} - {slot.hours.join(", ")}{" "}
                            <BsTrash
                              onClick={() =>
                                handleRemoveAvailabilitySlot(index)
                              }
                            />
                          </li>
                        ))}
                      </ul>
                    )}
                  </td>
                  <td>
                    <Button
                      variant="warning"
                      className="me-2"
                      onClick={() => handleEditService(service)}
                    >
                      Edit
                    </Button>
                    <Button
                      variant="danger"
                      onClick={() => handleDeleteService(service)}
                    >
                      Delete
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </Table>
        </div>
      )}
      {showForm && (
        <Button variant="secondary" onClick={handleSwitchToTable}>
          Cancel
        </Button>
      )}
      {showGarageSettings && (
        <div className="my-2">
          <GarageSettings onClose={handelSwitchSettings} />
        </div>
      )}
      {showGarageDates && <GarageDates onClose={handleShowGarageDates} />}
    </div>
  );
};

export default GarageDashboard;
