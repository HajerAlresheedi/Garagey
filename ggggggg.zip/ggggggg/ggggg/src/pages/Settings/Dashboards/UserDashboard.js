import React, { useState, useEffect } from "react";
import { Form, Container, Row, Col, Button } from "react-bootstrap";
import { BsPencilSquare, BsCheck, BsX } from "react-icons/bs";

const UserDashboard = () => {
  const [userData, setUserData] = useState({});
  const [oldPassword, setOldPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmNewPassword, setConfirmNewPassword] = useState("");
  const [isEditing, setIsEditing] = useState(false);
  const [error, setError] = useState("");
  const [changePassword, setChangePassword] = useState(false);
  const [selectedCars, setSelectedCars] = useState([]);
  const [availableCars, setAvailableCars] = useState([
    "Hatchback",
    "Minivan",
    "Convertible",
    "Sedan",
    "Crossover",
    "Cadillac",
    "Van",
  ]);
// Fetch user data from local storage
  useEffect(() => {
    const storedUserData = JSON.parse(localStorage.getItem("userData")) || {};
    setUserData(storedUserData);
    setSelectedCars(storedUserData.cars);
  }, []);

// Handle editing 
  const handleEditClick = () => {
    setIsEditing(true);
    setError("");
  };
 // Handle editing to save changes 
  const handleSaveClick = () => {
    if (changePassword && newPassword !== "") {
      if (oldPassword !== userData.password) {
        setError("Old password is incorrect");
        return;
      }
    }
    // create updated user data
    const updatedUserData = {
      ...userData,
      password: newPassword !== "" ? newPassword : userData.password,
      confirmPassword:
        newPassword !== "" ? newPassword : userData.confirmPassword,
      cars: selectedCars,
    };
   // updated local user data
    localStorage.setItem("registerData", JSON.stringify(updatedUserData));

    setUserData(updatedUserData);
    setOldPassword("");
    setNewPassword("");
    setConfirmNewPassword("");
    setIsEditing(false);
    setChangePassword(false);
    setError("");
  };

//handel updated user data
  const handleCancelClick = () => {
    setOldPassword("");
    setNewPassword("");
    setConfirmNewPassword("");
    setIsEditing(false);
    setError("");
  };
//handle input change
  const handleChange = (e) => {
    setUserData({ ...userData, [e.target.name]: e.target.value });
  };

  //handle add cars
  const handleCarAdd = (car) => {
    if (!selectedCars.includes(car)) {
      setSelectedCars((prevCars) => [...prevCars, car]);
      setAvailableCars((prevCars) =>
        prevCars.filter((availableCar) => availableCar !== car)
      );
    }
  };
 
  //handle remove cars
  const handleCarRemove = (car) => {
    setSelectedCars((prevCars) => prevCars.filter((c) => c !== car));
    setAvailableCars((prevCars) => [...prevCars, car]);
  };
  return (
    <Container className="mt-4 settings">
      <h2 className="mb-4">Settings</h2>
      <Form>
        <Row className="mb-3">
          <Col sm>
            <Form.Group controlId="formFirstName">
              <Form.Label>First Name</Form.Label>
              <Form.Control
                type="text"
                placeholder="Enter your first name"
                name="firstName"
                value={userData.firstName}
                onChange={handleChange}
                disabled={!isEditing}
              />
            </Form.Group>
          </Col>
          <Col sm>
            <Form.Group controlId="formLastName">
              <Form.Label>Last Name</Form.Label>
              <Form.Control
                type="text"
                placeholder="Enter your last name"
                name="lastName"
                value={userData.lastName}
                onChange={handleChange}
                disabled={!isEditing}
              />
            </Form.Group>
          </Col>
        </Row>
        <Row className="mb-3">
          <Col sm>
            <Form.Group controlId="formCars">
              {selectedCars.length > 0 && (
                <>
                  <Form.Label>My Cars</Form.Label>
                  <div className="selected-cars">
                    {selectedCars.map((car) => (
                      <div key={car} className="selected-car">
                        <span>{car}</span>
                        {isEditing && (
                          <BsX onClick={() => handleCarRemove(car)} />
                        )}
                      </div>
                    ))}
                  </div>
                </>
              )}
              {availableCars.length > 0 && (
                <div className="dropdown">
                  {isEditing && (
                    <button
                      className="btn btn-secondary btn-sm"
                      type="button"
                      id="carDropdown"
                      data-bs-toggle="dropdown"
                      aria-expanded="false"
                    >
                      Add Car
                    </button>
                  )}
                  <ul className="dropdown-menu" aria-labelledby="carDropdown">
                    {availableCars.map((car, i) => (
                      <li
                        key={i}
                        onClick={() => handleCarAdd(car)}
                        className="dropdown-item"
                      >
                        {car}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </Form.Group>
          </Col>
        </Row>
        <Row className="mb-3">
          <Col sm>
            <Form.Group controlId="formEmail">
              <Form.Label>Email</Form.Label>
              <Form.Control
                type="email"
                placeholder="Enter your email"
                name="email"
                value={userData.email}
                onChange={handleChange}
                disabled={!isEditing}
              />
            </Form.Group>
          </Col>
          <Col sm>
            <Form.Group controlId="formPhoneNumber">
              <Form.Label>Phone Number</Form.Label>
              <Form.Control
                type="tel"
                placeholder="Enter your phone number"
                name="phoneNumber"
                value={userData.phoneNumber}
                onChange={handleChange}
                disabled={!isEditing}
              />
            </Form.Group>
          </Col>
        </Row>
        <Row className="mb-3">
          <Col sm>
            <Form.Group controlId="formLocation">
              <Form.Label>Location</Form.Label>
              <Form.Control
                type="text"
                placeholder="Enter your location"
                name="location"
                value={userData.location}
                onChange={handleChange}
                disabled={!isEditing}
              />
            </Form.Group>
          </Col>
        </Row>
        {changePassword && (
          <>
            <Row className="mb-3">
              <Col sm>
                <Form.Group controlId="formOldPassword">
                  <Form.Label>Old Password</Form.Label>
                  <Form.Control
                    type="password"
                    placeholder="Enter your old password"
                    name="oldPassword"
                    value={oldPassword}
                    onChange={(e) => setOldPassword(e.target.value)}
                  />
                </Form.Group>
              </Col>
              <Col sm>
                <Form.Group controlId="formNewPassword">
                  <Form.Label>New Password</Form.Label>
                  <Form.Control
                    type="password"
                    placeholder="Enter your new password"
                    name="newPassword"
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                  />
                </Form.Group>
              </Col>
              <Col sm>
                <Form.Group controlId="formConfirmNewPassword">
                  <Form.Label>Confirm New Password</Form.Label>
                  <Form.Control
                    type="password"
                    placeholder="Confirm your new password"
                    name="confirmNewPassword"
                    value={confirmNewPassword}
                    onChange={(e) => setConfirmNewPassword(e.target.value)}
                  />
                </Form.Group>
              </Col>
            </Row>
          </>
        )}
        {/*if there is error */}
        {error && <div className="text-danger mb-3">{error}</div>}
        <Row className="mb-3">
          <Col>
            {isEditing ? (
              <>
                <div className="pb-2">
                  <Button
                    variant="info"
                    className="text-light"
                    onClick={() => setChangePassword(true)}
                  >
                    <BsPencilSquare className="mb-1" />
                    Password
                  </Button>
                </div>
                <Button
                  variant="success"
                  className="me-2"
                  onClick={handleSaveClick}
                >
                  <BsCheck className="mb-1" /> Save
                </Button>
                <Button variant="secondary" onClick={handleCancelClick}>
                  <BsX className="mb-1" /> Cancel
                </Button>
              </>
            ) : (
              <>
                <Button variant="primary" onClick={handleEditClick}>
                  <BsPencilSquare className="mb-1" /> Edit
                </Button>
              </>
            )}
          </Col>
        </Row>
      </Form>
    </Container>
  );
};

export default UserDashboard;
