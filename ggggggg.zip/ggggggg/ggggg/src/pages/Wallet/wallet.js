import React from "react";
const wallet = () => {
  return <div>Wallet</div>;
};

export default wallet;
