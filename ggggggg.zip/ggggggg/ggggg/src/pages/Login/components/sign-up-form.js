import React, { useState } from "react";
import {
  FaUser,
  FaEnvelope,
  FaLock,
  FaLocationArrow,
  FaCar,
  FaPhone,
  FaTimes,
} from "react-icons/fa";
import { Link } from "react-router-dom";

function SignupForm({ handleToggleCard }) {
  const [signupErrors, setSignupErrors] = useState({
    firstName: "",
    lastName: "",
    email: "",
    password: "",
    confirmPassword: "",
    location: "",
    phoneNumber: "",
  });
  const [signupData, setSignupData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    password: "",
    cars: [],
    location: "",
    phoneNumber: "",
  });
  const [selectedCars, setSelectedCars] = useState([]);
  const data = [
    { Cars: "Hatchback", id: 1 },
    { Cars: "Minivan", id: 2 },
    { Cars: "Convertible", id: 3 },
    { Cars: "Sedan", id: 4 },
    { Cars: "Crossover", id: 5 },
    { Cars: "Cadillac", id: 6 },
    { Cars: "Van", id: 7 },
  ];

  const handleCarRemove = (car) => {
    setSelectedCars((prevCars) => prevCars.filter((c) => c !== car));
  };

  const handleGetLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          setSignupData((prevData) => ({
            ...prevData,
            location: `Latitude: ${latitude}, Longitude: ${longitude}`,
          }));
        },
        (error) => {
          console.error("Error getting location:", error.message);
          setSignupData((prevData) => ({
            ...prevData,
            location: "Failed to get location",
          }));
        }
      );
    } else {
      setSignupData((prevData) => ({
        ...prevData,
        location: "Geolocation is not supported by this browser.",
      }));
    }
  };

  const handleCarSelect = (car) => {
    if (!selectedCars.includes(car)) {
      setSelectedCars((prevCars) => [...prevCars, car]);
    }
  };

  const handleSignupSubmit = (e) => {
    e.preventDefault();

    if (validateSignup()) {
      const userData = {
        ...signupData,
        cars: selectedCars,
        type: "user",
      };

      // Get existing registerData from local storage or initialize an empty array
      const existingRegisterData =
        JSON.parse(localStorage.getItem("registerData")) || [];

      // Add the new user data to the array
      const updatedRegisterData = [...existingRegisterData, userData];

      // Store the updated registerData back to local storage
      localStorage.setItem("registerData", JSON.stringify(updatedRegisterData));

      handleToggleCard();
    }
  };

  const validateSignup = () => {
    let isValid = true;
    const errors = {};

    if (!signupData.firstName) {
      errors.firstName = "First Name is required";
      isValid = false;
    }

    if (!signupData.lastName) {
      errors.lastName = "Last Name is required";
      isValid = false;
    }

    if (!signupData.email) {
      errors.email = "Email is required";
      isValid = false;
    } else if (!/^\S+@\S+$/i.test(signupData.email)) {
      errors.email = "Valid email address is required";
      isValid = false;
    }

    if (!signupData.password) {
      errors.password = "Password is required";
      isValid = false;
    }

    if (signupData.password !== signupData.confirmPassword) {
      errors.confirmPassword = "Passwords do not match";
      isValid = false;
    }

    if (!signupData.location) {
      errors.location = "Location is required";
      isValid = false;
    }

    if (!signupData.phoneNumber) {
      errors.phoneNumber = "Phone Number is required";
      isValid = false;
    }

    setSignupErrors(errors);
    return isValid;
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
      setSignupData((prevData) => ({ ...prevData, [name]: value }));
      setSignupErrors((prevErrors) => ({ ...prevErrors, [name]: "" }));
   
  };

  return (
    <form onSubmit={handleSignupSubmit}>
      <h1>Sign Up</h1>
      <div className="LoginSignup-fields">
        <div className="row">
          <div className="col">
            <div className="input-group">
              <span className="input-icon">
                <FaUser />
              </span>
              <input
                type="text"
                placeholder="First Name"
                className={`form-control ${
                  signupErrors.firstName ? "is-invalid" : ""
                }`}
                name="firstName"
                value={signupData.firstName}
                onChange={(e) => handleInputChange(e)}
              />
              {signupErrors.firstName && (
                <div className="invalid-feedback">{signupErrors.firstName}</div>
              )}
            </div>
          </div>
          <div className="col">
            <div className="input-group">
              <span className="input-icon">
                <FaUser />
              </span>
              <input
                type="text"
                placeholder="Last Name"
                className={`form-control ${
                  signupErrors.lastName ? "is-invalid" : ""
                }`}
                name="lastName"
                value={signupData.lastName}
                onChange={(e) => handleInputChange(e)}
              />
              {signupErrors.lastName && (
                <div className="invalid-feedback">{signupErrors.lastName}</div>
              )}
            </div>
          </div>
        </div>
        <div className="row">
          <div className="col">
            <div className="input-group">
              <span className="input-icon">
                <FaLock />
              </span>
              <input
                type="password"
                placeholder="Password"
                className={`form-control ${
                  signupErrors.password ? "is-invalid" : ""
                }`}
                name="password"
                value={signupData.password}
                onChange={(e) => handleInputChange(e)}
              />
              {signupErrors.password && (
                <div className="invalid-feedback">{signupErrors.password}</div>
              )}
            </div>
          </div>
          <div className="col">
            <div className="input-group">
              <span className="input-icon">
                <FaLock />
              </span>
              <input
                type="password"
                placeholder="Confirm Password"
                className={`form-control ${
                  signupErrors.confirmPassword ? "is-invalid" : ""
                }`}
                name="confirmPassword"
                value={signupData.confirmPassword}
                onChange={(e) => handleInputChange(e)}
              />
              {signupErrors.confirmPassword && (
                <div className="invalid-feedback">
                  {signupErrors.confirmPassword}
                </div>
              )}
            </div>
          </div>
        </div>
        <div className="row">
          <div className="col">
            <div className="input-group">
              <span className="input-icon">
                <FaEnvelope />
              </span>
              <input
                type="email"
                placeholder="Email Address"
                className={`form-control ${
                  signupErrors.email ? "is-invalid" : ""
                }`}
                name="email"
                value={signupData.email}
                onChange={(e) => handleInputChange(e)}
              />
              {signupErrors.email && (
                <div className="invalid-feedback">{signupErrors.email}</div>
              )}
            </div>
          </div>
        </div>
        <div className="row">
          <div className="col">
            <div className="input-group">
              <span className="input-icon">
                <FaLocationArrow />
              </span>
              <button
                type="button"
                className="btn btn-secondary btn-sm me-2"
                onClick={handleGetLocation}
              >
                Get Location
              </button>
              {signupData.location && (
                <div className="location-info">{signupData.location}</div>
              )}
            </div>
            {signupErrors.location && (
              <div className="invalid-feedback">{signupErrors.location}</div>
            )}
          </div>
          <div className="col">
            <div className="input-group">
              <span className="input-icon" style={{ height: "31px" }}>
                <FaCar />
              </span>
              <div className="dropdown">
                <button
                  className="btn btn-secondary btn-sm me-2 dropdown-toggle"
                  type="button"
                  id="carDropdown"
                  data-bs-toggle="dropdown"
                  aria-expanded="false"
                >
                  Select Cars
                </button>
                <ul className="dropdown-menu" aria-labelledby="carDropdown">
                  {data.map((option) => (
                    <li
                      key={option.id}
                      onClick={() => handleCarSelect(option.Cars)}
                    >
                      <Link className="dropdown-item" to="#">
                        {option.Cars}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>

        <div className="row">
          <div className="col">
            <div className="input-group">
              <span className="input-icon">
                <FaPhone />
              </span>
              <input
                type="text"
                placeholder="Phone Number"
                className={`form-control ${
                  signupErrors.phoneNumber ? "is-invalid" : ""
                }`}
                name="phoneNumber"
                value={signupData.phoneNumber}
                onChange={(e) => handleInputChange(e)}
              />
              {signupErrors.phoneNumber && (
                <div className="invalid-feedback">
                  {signupErrors.phoneNumber}
                </div>
              )}
            </div>
          </div>
        </div>
        <div className="selected-cars">
          {selectedCars.map((car) => (
            <div key={car} className="selected-car">
              <span>{car}</span>
              <FaTimes onClick={() => handleCarRemove(car)} />
            </div>
          ))}
        </div>
      </div>

      <div className="done-btn mb-3 mt-3">
        <button type="submit" className="btn w-100 h-100">
          Sign up
        </button>
      </div>
      <p className="loginsignup-login" onClick={handleToggleCard}>
        Already have an account? <span>Login here</span>
      </p>
    </form>
  );
}

export default SignupForm;
