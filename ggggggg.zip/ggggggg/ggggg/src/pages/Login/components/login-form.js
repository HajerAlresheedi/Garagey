import React, { useState } from "react";
import { FaEnvelope, FaLock } from "react-icons/fa";

function LoginForm({ handleToggleCard }) {
  const [loginData, setLoginData] = useState({ email: "", password: "" });
  const [loginErrors, setLoginErrors] = useState({ email: "", password: "" });
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setLoginData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
    setLoginErrors((prevErrors) => ({
      ...prevErrors,
      [name]: "",
    }));
  };
  const validateLogin = () => {
    let isValid = true;
    const errors = {};

    if (!loginData.email) {
      errors.email = "Email is required";
      isValid = false;
    }

    if (!loginData.password) {
      errors.password = "Password is required";
      isValid = false;
    }

    setLoginErrors(errors);
    return isValid;
  };

  const handleLoginSubmit = (e) => {
    e.preventDefault();

    if (validateLogin()) {
      const storedUserData = JSON.parse(localStorage.getItem("registerData"));
      console.log("storedUserData", storedUserData);
      if (storedUserData) {
        const user = storedUserData.find(
          (data) =>
            data.email === loginData.email &&
            data.password === loginData.password
        );

        if (user) {
          localStorage.setItem("userData", JSON.stringify(user));
          window.location.pathname = "/";
        } else {
          setLoginErrors({ email: "Invalid email or password", password: "" });
          console.log("Invalid login credentials");
        }
      } else {
        setLoginErrors({ email: "User not found", password: "" });
      }
    }
  };

  return (
    <form onSubmit={handleLoginSubmit}>
      <h1>Login</h1>
      <div className="LoginSignup-fields">
        <div className="input-group">
          <span className="input-icon">
            <FaEnvelope />
          </span>
          <input
            type="email"
            placeholder="Email Address"
            className={`form-control ${loginErrors.email ? "is-invalid" : ""}`}
            name="email"
            value={loginData.email}
            onChange={(e) => handleInputChange(e)}
          />
        </div>
        {loginErrors.email && (
          <div className="invalid-feedback">{loginErrors.email}</div>
        )}
        <div className="input-group">
          <span className="input-icon">
            <FaLock />
          </span>
          <input
            type="password"
            placeholder="Password"
            className={`form-control ${
              loginErrors.password ? "is-invalid" : ""
            }`}
            name="password"
            value={loginData.password}
            onChange={(e) => handleInputChange(e)}
          />
        </div>
        {loginErrors.password && (
          <div className="invalid-feedback">{loginErrors.password}</div>
        )}
      </div>
      <div className="done-btn mb-3 mt-3">
        <button type="submit" className="btn w-100 h-100">
          Login
        </button>
      </div>
      <p className="loginsignup-login" onClick={handleToggleCard}>
        Don't have an account? <span>Sign up here</span>
      </p>
    </form>
  );
}

export default LoginForm;
