import React, { useState, useEffect } from "react";
import { Container, Card, Button, Row, Col, Modal } from "react-bootstrap";
import { FaTrash } from "react-icons/fa";



const CheckoutPage = ({handleClose}) => {
  const [cart, setCart] = useState([]);
  const [selectedOrders, setSelectedOrders] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [isCartEmpty, setIsCartEmpty] = useState(false);

  useEffect(() => {
    const storedOrders = localStorage.getItem("cart");
    setCart(storedOrders);
    if (storedOrders) {
      setSelectedOrders(JSON.parse(storedOrders));
    }
  }, [cart]);

  useEffect(() => {
    setIsCartEmpty(selectedOrders.length === 0);
  }, [selectedOrders]);

  const handleRemoveOrder = (orderId, selectedDay, selectedHour) => {
    const updatedOrders = selectedOrders.filter((order) => {
      return !(
        order.id === orderId &&
        order.availability.some(
          (slot) => slot.day === selectedDay && slot.hours === selectedHour
        )
      );
    });

    setSelectedOrders(updatedOrders);
    localStorage.setItem("cart", JSON.stringify(updatedOrders));
  };

  const handleCheckout = () => {
    setShowModal(true);
  };

  const handleCloseModal = () => {
    setShowModal(false);
  };

  const handleConfirmCheckout = () => {
    const checkoutData = selectedOrders.map((order) => ({
      ...order,
    }));

    localStorage.setItem("reservations", JSON.stringify(checkoutData));

    localStorage.removeItem("cart");

    setShowModal(false);
    handleClose();
  };

  const getTotalAmount = () => {
    return selectedOrders
      .reduce((total, order) => total + parseFloat(order.price.slice(1)), 0)
      .toFixed(2);
  };

  const ProductCard = ({ order, onRemove }) => {
    const handleRemove = () => {
      onRemove(
        order.id,
        order.availability[0].day,
        order.availability[0].hours
      );
    };

    return (
      <Card className="mb-3 border-0 shadow-sm">
        <Card.Body>
          <Card.Title className="mb-3">{order.serviceName}</Card.Title>
          <Card.Text>
            <strong>Price:</strong> {order.price} <br />
            <strong>Duration:</strong> {order.duration} <br />
            <strong>Description:</strong> {order.description} <br />
            <strong>Date:</strong>{" "}
            {order.availability.map((slot, i) => (
              <span key={i} className="d-block">
                <strong>Day: </strong> {slot.day} <br />
                <strong>Hour: </strong>
                {slot.hours}
              </span>
            ))}
          </Card.Text>
          <Button variant="danger" onClick={handleRemove} className="mt-3">
            Remove <FaTrash className="mb-1" />
          </Button>
        </Card.Body>
      </Card>
    );
  };

  return (
    <Container className="py-5">
      {isCartEmpty && (
        <p>
          Your cart is empty. Add items to your cart to proceed with the
          checkout.
        </p>
      )}

      {!isCartEmpty && (
        <Row>
          <Col md={8} style={{ maxHeight: "400px", overflowY: "auto" }}>
            {selectedOrders.map((order, i) => (
              <ProductCard key={i} order={order} onRemove={handleRemoveOrder} />
            ))}
          </Col>

          <Col md={4}>
            <Card className="border-0 shadow-sm mb-4">
              <Card.Body>
                <Card.Title className="mb-4">Payment Details</Card.Title>
                <ul className="list-unstyled">
                  {selectedOrders.map((order, i) => (
                    <li key={i} className="mb-2">
                      <strong>{order.serviceName}</strong> - {order.price}
                    </li>
                  ))}
                </ul>
                <hr />
                <p className="mt-4">
                  <strong>Total Amount:</strong> KD {getTotalAmount()}
                </p>
                <Button
                  variant="primary"
                  style={{
                    backgroundColor: "#7bbcc9",
                    borderColor: "#7bbcc9",
                    color: "#fff",
                  }}
                  onClick={handleCheckout}
                  className="mt-3 w-100"
                >
                  Proceed to Checkout
                </Button>
              </Card.Body>
            </Card>
          </Col>
        </Row>
      )}

      <Modal show={showModal} onHide={handleCloseModal}>
        <Modal.Header closeButton>
          <Modal.Title>Confirmation</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <p>Are you sure you want to proceed with the checkout?</p>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleCloseModal}>
            Close
          </Button>
          <Button variant="primary" onClick={handleConfirmCheckout}>
            Confirm Checkout
          </Button>
        </Modal.Footer>
      </Modal>
    </Container>
  );
};

export default CheckoutPage;
