import React, { useState, useEffect } from "react";
import { FaShoppingCart, FaCheckCircle } from "react-icons/fa";
import { Toast, Button, Modal, Alert } from "react-bootstrap";
import { servicesData } from "./services-data";
import Checkout from "../check-out";

const ServiceTab = ({ storeName }) => {
  const [selectedService, setSelectedService] = useState(null);
  const [cart, setCart] = useState([]);
  const [showNotification, setShowNotification] = useState(false);
  const [showAvailabilityModal, setShowAvailabilityModal] = useState(false);
  const [selectedDay, setSelectedDay] = useState(null);
  const [selectedHour, setSelectedHour] = useState(null);
  const [showSuccessAlert, setShowSuccessAlert] = useState(false);
  const [showNoCarsSelected, setShowNoCarsSelected] = useState(false);
  const [showCheckoutModal, setShowCheckoutModal] = useState(false);
  const [showCarSelectionModal, setShowCarSelectionModal] = useState(false);
  const [availableCars, setAvailableCars] = useState([]);
  const [userType, setUserType] = useState("");

  useEffect(() => {
    if (!selectedService && servicesData.length > 0) {
      setSelectedService(servicesData[0]);
    }

    const storedCart = JSON.parse(localStorage.getItem("cart"));
    if (storedCart) {
      setCart(storedCart);
    }

    const storeData = JSON.parse(localStorage.getItem("userData"));
    if (storeData) {
      setAvailableCars(storeData.cars);
    }
    setUserType(storeData.type);
  }, [selectedService]);

  const handleToggleDetails = (service) => {
    setSelectedService((prevService) =>
      prevService === service ? null : service
    );
    setSelectedDay(null);
    setSelectedHour(null);
  };

  const handleAddToCart = (service) => {
    if (!availableCars || availableCars.length === 0) {
      setShowNoCarsSelected(true);
      return;
    }

    setShowCarSelectionModal(true);
  };

  const handleCarSelectionClose = () => {
    setShowCarSelectionModal(false);
  };

  const handleCarSelect = (car) => {
    setSelectedService((prevService) => ({
      ...prevService,
      car: car,
    }));
    setShowCarSelectionModal(false);
    setShowAvailabilityModal(true);
  };

  const renderHours = () => {
    if (selectedDay) {
      const selectedSlot = selectedService.availability.find(
        (slot) => slot.time === selectedDay
      );

      return (
        selectedSlot &&
        selectedSlot.hours.map((hour) => (
          <Button
            key={hour}
            variant={
              selectedHour && selectedHour === hour
                ? "success"
                : "outline-success"
            }
            className="m-1"
            onClick={() => handleHourSelect(hour)}
          >
            {hour}
          </Button>
        ))
      );
    }
  };

  const handleNotificationClose = () => {
    setShowNotification(false);
  };

  const handleModalClose = () => {
    setShowAvailabilityModal(false);
    setSelectedDay(null);
    setSelectedHour(null);
  };

  const handleDaySelect = (day) => {
    setSelectedDay(day);
  };

  const handleHourSelect = (hour) => {
    setSelectedHour(hour);
  };

  const handleAddToCartWithSlot = () => {
    if (selectedDay && selectedHour) {
      const formattedDate = new Date().toLocaleDateString();
      const selectedSlot = {
        day: selectedDay,
        hours: selectedHour,
        time: formattedDate,
      };

      const isServiceInCart = cart.some(
        (item) =>
          item.id === selectedService.id &&
          item.storeName === storeName &&
          item.availability.some(
            (slot) => slot.day === selectedDay && slot.hours === selectedHour
          )
      );

      if (isServiceInCart) {
        setShowNotification(true);
      } else {
        const updatedCart = [
          ...cart,
          {
            ...selectedService,
            storeName,
            availability: [selectedSlot],
          },
        ];
        setCart(updatedCart);
        localStorage.setItem("cart", JSON.stringify(updatedCart));
        setShowAvailabilityModal(false);
        setSelectedDay(null);
        setSelectedHour(null);
        setShowSuccessAlert(true);
      }
    }
  };

  const handleRemoveItem = (itemId) => {
    const updatedCart = cart.filter((item) => item.id !== itemId);
    setCart(updatedCart);
    localStorage.setItem("cart", JSON.stringify(updatedCart));
  };

  const handleShowCheckout = () => {
    setShowCheckoutModal(true);
  };

  const handleCloseCheckout = () => {
    setShowCheckoutModal(false);
  };

  return (
    <div className="container mt-4">
      <div className="d-flex flex-row flex-wrap gap-1">
        {servicesData.map((service) => (
          <div
            key={service.id}
            className={`mb-1 border p-1 ${
              selectedService?.id === service.id ? "bg-light" : ""
            }`}
          >
            <h3
              onClick={() => handleToggleDetails(service)}
              style={{ cursor: "pointer" }}
            >
              {service.serviceName}
            </h3>
          </div>
        ))}
      </div>
      {selectedService && (
        <div className="mt-4 border p-3">
          <h3>{selectedService.serviceName}</h3>
          <p>Price: {selectedService.price}</p>
          <p>Description: {selectedService.description}</p>
          <p>Duration: {selectedService.duration}</p>
          {userType === "user" && (
            <div className="w-100 d-flex justify-content-end">
              <Button
                variant="outline-dark"
                onClick={() => handleAddToCart(selectedService)}
              >
                <FaShoppingCart className="mr-2" />
              </Button>
              <Button
                variant="success"
                className="ml-2"
                onClick={handleShowCheckout}
              >
                Checkout
              </Button>
            </div>
          )}
        </div>
      )}

      <Toast
        show={showNotification}
        onClose={handleNotificationClose}
        className="position-fixed bottom-0 end-0 m-3"
      >
        <Toast.Header>
          <strong className="me-auto">Alert</strong>
        </Toast.Header>
        <Toast.Body>This Service is already in your cart!</Toast.Body>
      </Toast>

      <Modal
        show={showCarSelectionModal}
        onHide={handleCarSelectionClose}
        centered
      >
        <Modal.Header closeButton>
          <Modal.Title>Select Car</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <div className="selected-cars">
            {availableCars?.map((car) => (
              <div
                key={car}
                className="selected-car"
                onClick={() => handleCarSelect(car)}
              >
                <span>{car}</span>
              </div>
            ))}
          </div>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleCarSelectionClose}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>

      <Modal show={showAvailabilityModal} onHide={handleModalClose} centered>
        <Modal.Header closeButton>
          <Modal.Title>Select Availability</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {selectedService &&
            selectedService.availability.map((slot) => (
              <Button
                key={slot.day}
                variant={
                  selectedDay && selectedDay === slot.day
                    ? "primary"
                    : "outline-primary"
                }
                className="m-1"
                onClick={() => handleDaySelect(slot.time)}
              >
                {slot.day},{slot.time}
              </Button>
            ))}
          <div className="mt-3">
            {selectedService &&
              selectedService.availability.length > 0 &&
              renderHours()}
          </div>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleModalClose}>
            Close
          </Button>
          <Button
            variant="primary"
            onClick={handleAddToCartWithSlot}
            disabled={!selectedDay || !selectedHour}
          >
            Add to Cart
          </Button>
        </Modal.Footer>
      </Modal>

      <Modal
        show={showCheckoutModal}
        onHide={handleCloseCheckout}
        centered
        size="xl"
      >
        <Modal.Header closeButton>
          <Modal.Title>
            <h1 className="mb-4">
              Checkout <FaShoppingCart className="mb-2" />
            </h1>
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Checkout
            cart={cart}
            handleClose={handleCloseCheckout}
            handleRemoveItem={handleRemoveItem}
          />
        </Modal.Body>
      </Modal>

      <Alert
        show={showSuccessAlert}
        variant="success"
        onClose={() => setShowSuccessAlert(false)}
        dismissible
        className="position-fixed bottom-0 end-0 m-3"
      >
        <Alert.Heading>
          <FaCheckCircle className="mr-2" />
          Success!
        </Alert.Heading>
        <p>The service has been added to your cart.</p>
      </Alert>
      <Alert
        show={showNoCarsSelected}
        variant="success"
        onClose={() => setShowNoCarsSelected(false)}
        dismissible
        className="position-fixed bottom-0 end-0 m-3"
      >
        <Alert.Heading>
          <FaCheckCircle className="mr-2" />
          Warning!
        </Alert.Heading>
        <p>Please Select the car you want for this service.</p>
      </Alert>
    </div>
  );
};

export default ServiceTab;