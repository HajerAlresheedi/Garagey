// Function to generate random availability for a service
const generateRandomAvailability = () => {
  const days = [
    "Monday",
    "Tuesday",
    "Wednesday",
    "Thursday",
    "Friday",
    "Saturday",
    "Sunday",
  ];

  // Random number of days (1 to 7)
  const numDays = Math.floor(Math.random() * 7) + 1;//

  const availabilitySlots = [];

  const usedDays = new Set(); // To track used days

  for (let d = 0; d < numDays; d++) {
    let day;
    do {
      day = days[Math.floor(Math.random() * days.length)]; // Random day
    } while (usedDays.has(day));

    //usedDays.add(day);

    const numAvailabilitySlots = Math.floor(Math.random() * 3) + 1; // Random number of availability slots (1 to 3)
    const hours = [];
    const currentDate = new Date();
    const randomDate = new Date(
      currentDate.getTime() -
        Math.floor(Math.random() * 365) * 24 * 60 * 60 * 1000
    );

    for (let i = 0; i < numAvailabilitySlots; i++) {
      let hour;
      do {
        hour = Math.floor(Math.random() * 12) + 8; // Random hours between 8 and 19
      } while (hours.includes(hour));

      hours.push(hour);
    }

    availabilitySlots.push({
      day: day,
      hours: hours,
      time: `${randomDate.getFullYear()}-${randomDate.getDate()}-${
        randomDate.getMonth() + 1
      }`,
    });
    //"2018-12-30"
  }

  return availabilitySlots;
};

export const servicesData = [
  {
    id: 1,
    serviceName: "Oil Change",
    price: "KD30",
    description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit.",
    duration: "30 minutes",
    availability: [{
      day: "Friday",
      hours: ["2","3:30"] ,
      time: '2023-11-26' ,
    }]
  },
  {
    id: 2,
    serviceName: "Tire Rotation",
    price: "KD20",
    description:
      "Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.",
    duration: "45 minutes",
    availability: generateRandomAvailability(),
  },
  {
    id: 3,
    serviceName: "Brake Inspection",
    price: "KD40",
    description: "Sed ut perspiciatis unde omnis iste natus error sit.",
    duration: "60 minutes",
    availability: generateRandomAvailability(),
  },
  {
    id: 4,
    serviceName: "Brake Inspection",
    price: "KD40",
    description: "Sed ut perspiciatis unde omnis iste natus error sit.",
    duration: "60 minutes",
    availability: generateRandomAvailability(),
  },
];
