// ReviewsTab.jsx
import React from "react";

const ReviewsTab = () => {
  const reviewsData = [
    {
      id: 1,
      userName: "John Doe",
      rating: 5,
      comment: "Great service!",
      avatar: "https://via.placeholder.com/40",
    },
    {
      id: 2,
      userName: "Jane Smith",
      rating: 4,
      comment: "Very satisfied.",
      avatar: "https://via.placeholder.com/40",
    },
    {
      id: 3,
      userName: "Bob Johnson",
      rating: 3,
      comment: "Average experience.",
      avatar: "https://via.placeholder.com/40",
    },
    // Add more dummy review data as needed
  ];

  return (
    <div className="container mt-4">
      <h2 className="mb-3">Customer Reviews</h2>
      <div className="list-group">
        {reviewsData.map((review) => (
          <div key={review.id} className="list-group-item">
            <div className="d-flex align-items-start">
              <img
                src={review.avatar}
                alt="User Avatar"
                className="me-3 rounded-circle"
              />
              <div>
                <h6 className="mb-0">{review.userName}</h6>
                <small>Rating: {review.rating}</small>
                <p className="mb-0">{review.comment}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ReviewsTab;
