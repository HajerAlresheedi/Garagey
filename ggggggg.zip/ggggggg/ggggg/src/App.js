import Navbarr from "./components/Navbarr/Navbarr";
import Home from "./pages/Home/Home";
import Reservation from "./pages/Reservation/Reservation";
import GarageStore from "./pages/GarageStore/GarageStore";
import Settings from "./pages/Settings/Settings";

import LoginSignup from "./pages/Login/LoginSignup";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Footer from "./components/Footer/Footer";
import Garage from "./pages/Garage/Garage";

function App() {
  return (
    <BrowserRouter>
      <Navbarr />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/Reservation" element={<Reservation />} />
        <Route path="/Garages" element={<GarageStore />} />
        <Route path="/Garages/:id" element={<Garage />} />
        <Route path="/Settings" element={<Settings />} />
        
        <Route path="/wallet" element={<wallet />} />
        <Route path="/LoginSignup" element={<LoginSignup />} />
      </Routes>
      <Footer />
    </BrowserRouter>
  );
}

export default App;
